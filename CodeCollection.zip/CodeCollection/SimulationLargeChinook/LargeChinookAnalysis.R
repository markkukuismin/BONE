
# 05.08.2019

# Simulate SNPs with 100 % known population structure using the ADMIXTURE model

library(glmnet)
library(rubias)
library(gtools)
library(igraph)
library(assignPOP)
library(radmixture)
library(data.table)

# Load functions needed for the network inference method:

source("NetworkMethod/impute.R")
source("NetworkMethod/LASSOSolPath.R")
source("NetworkMethod/SolPathInference.R")
source("NetworkMethod/WTAInference.R")

source("radmixtureEstimator.R")
source("Convert2TwoColumnformat.R")

##########################################################################

# Simulate SNPs with the ADMIXTURE model:

# Data available at https://datadryad.org/resource/doi:10.5061/dryad.rs4v1

# The following changes have been made into the original "genepop_western_alaska_chinook_RAD" file:

# 1) Remove all commas

# 2) Remove "extra" zeros. For example:

# 0303 -> 3 3
# 0304 -> 3 4
# 0102 -> 1 2 

# and so on...

ChinookData = read.table("genepop_western_alaska_chinook_RAD_Modified.txt",skip = 10945, fill = T)

ChinookData[1:5,1:10]

which(ChinookData$V1 == "Pop")

PopNames = as.character(ChinookData[which(ChinookData$V1 == "Pop"),2])

PopSizes = diff(c(which(ChinookData$V1 == "Pop"), nrow(ChinookData)+1)) - 1

sum(PopSizes)
nrow(ChinookData[which(ChinookData$V1 != "Pop"),])

ChinookData = ChinookData[-which(ChinookData$V1 == "Pop"),]

ChinookData[1:5,1:7]

ChinookData = ChinookData[ ,-1]

ChinookData$V2 = as.integer(ChinookData$V2)

Pop = rep(PopNames, times = PopSizes)

repunit = Pop

Paternal = repunit # Dummy variable
Maternal = repunit
Sex = rep(0, nrow(ChinookData))
Affection = rep(-9, nrow(ChinookData))

ChinookData = cbind(Pop, repunit, Paternal, Maternal, Sex, Affection, ChinookData, stringsAsFactors = F)

##################

table(ChinookData$repunit)

# Choose three populations, one "outsider" population (no match in baseline) and one dummy individual:

Ind = ChinookData$repunit %in% c("Koktuli", "Anvik", "Kogrukluk", "Tubutulik") 

# Koktuli represents here the outsider population

Ind[length(Ind)] = T

ChinookData = ChinookData[Ind, ]

table(ChinookData$repunit)

# There are many missing genotypes. Impute them with random selection of genotype based on the allele frequencies
# across the entire baseline (not done here)

G = generateG(ChinookData) # ncol(G) = nmb of non-missing genotypes of ADMIXData

dim(G)

Pops = ChinookData[ ,c(2,4)]

Pops = as.data.frame(Pops)

colnames(Pops) = c("pop","ID")

rownames(Pops) = Pops$ID

table(Pops$pop)

initQ = initQF(g = G, pop = Pops, model="supervised")

# Only the F matrix is needed:

Fmatrix = initQ$f

dim(Fmatrix)

##########################################################################

# Fix the Q matrix:

HugePopsSize = 2000

Q = matrix(0,HugePopsSize,nrow(Fmatrix))

Q[1:500, 1] = 1
Q[501:1000, 2] = 1
Q[1001:1500, 3] = 1
Q[1501:2000, 4] = 1

#barplot(t(Q), col=rainbow(ncol(Q)))

##########################################################################

# Now we can simulate the SNP data

G1 = Q%*%Fmatrix
dim(G1)
G1[1:5,1:5]

G2 = Q%*%(1-Fmatrix)

IsOne = G1^2 + 2*G1*G2 + G2^2

all.equal(IsOne, matrix(1,nrow(IsOne), ncol(IsOne)))

N = nrow(Q)
L = ncol(Fmatrix)

SimSnps = matrix(NA,N,L)

for(i in 1:N){
  for(j in 1:L){
    
    SimSnps[i,j] = sample(c(2,1,0), 1, prob=c(G1[i,j]^2, 2*G1[i,j]*G2[i,j], G2[i,j]^2))
    
  }
}

dim(SimSnps) # nrow = nmb of individuals, ncol = nmb of SNPs

##########################################################################
##########################################################################

# A function to calculate Mean Squared Errors:

MSE = function(x,y){
  
  mean((x-y)^2)
  
}

##########################################################################
##########################################################################

# Draw 100 baseline individuals from three large population and 10, 20 and 50 mixture individuals
# from these population. In addition, draw 10 mixture individuals from one population but no baseline individuals: 

b = c(100, 100, 100)
m = c(10, 20, 50)

NmbofOut = 10

##########

M = 50 # Number of simulation rounds

Results = matrix(0, nrow=M, ncol=13)
colnames(Results) = c("Prob.origin.ADMIXTURE","Mix.Prop.ADMIXTURE",
                      "Prob.origin.RUBIAS.MCMC","Mix.Prop.RUBIAS.MCMC", "Mix.Prop.RUBIAS.PB",
                      "Prob.origin.Net.WTA","Mix.Prop.Net.WTA",
                      "Prob.origin.Net.SolPath","Mix.Prop.Net.SolPath",
                      "Prob.origin.AssignPOP.SVM","Mix.Prop.AssignPOP.SVM",
                      "Prob.origin.AssignPOP.NB","Mix.Prop.AssignPOP.NB")

Results = as.data.frame(Results)

# How accurate are the assignments?

AssignmentResults = matrix(0, nrow=M, ncol=6)
colnames(AssignmentResults) = c("ADMIXTURE", "RUBIAS", "Net.WTA", "Net.SolPath", "AssignPOPNB", "AssignPOPSVM")

AssignmentResults = as.data.frame(AssignmentResults)

TP = rep(0, M)
FP = rep(0, M)

for(k in 1:M){
  
  # Draw 100 baseline individuals from three large population and 10, 20 and 50 mixture individuals
  # from these population. In addition, draw 10 mixture individuals from one population but no baseline individuals: 
  
  Sout = sample(1:500, NmbofOut) # Outgroup members
  Sout = sort(Sout)
  
  SA = sample(501:1000, b[1] + m[1])
  SA = sort(SA)
  
  SB = sample(1001:1500, b[2] + m[2])
  SB = sort(SB)
  
  SC = sample(1501:2000, b[3] + m[3])
  SC = sort(SC)
  
  Reference = c(SA[1:b[1]], SB[1:b[2]], SC[1:b[3]])
  
  Mixture = c(SA[101:(b[1] + m[1])], SB[101:(b[2] + m[2])], SC[101:(b[3] + m[3])], Sout)
  Mixture = sort(Mixture)
  
  ReferenceData = SimSnps[Reference, ]
  ReferenceData = as.data.frame(ReferenceData)
  
  MixtureData = SimSnps[Mixture, ]
  MixtureData = as.data.frame(MixtureData)
  
  ################################################
  
  SampleSizeBaselinePop = nrow(ReferenceData)
  
  Y = cbind(t(ReferenceData),t(MixtureData))
  
  colnames(Y) = as.character(1:ncol(Y))
  
  sample_type = rep("reference", nrow(ReferenceData))
  
  repunit = c(rep("POP1", b[1]), rep("POP2", b[2]), rep("POP3", b[3]))
  
  collection = c(rep("POP1.1", b[1]), rep("POP2.1", b[2]), rep("POP3.1", b[3]))
  
  indiv = as.character(1:nrow(ReferenceData)) # Fake ID
  
  ReferenceData = cbind(sample_type, repunit, collection, indiv, ReferenceData, stringsAsFactors = FALSE)
  
  ##
  
  sample_type = rep("mixture", nrow(MixtureData))
  
  repunit = rep(NA_character_, sum(m) + NmbofOut)
  
  collection = rep("rec1", sum(m) + NmbofOut)
  
  indiv = as.character((nrow(ReferenceData) + 1):ncol(Y)) # Fake ID
  
  MixtureData = cbind(sample_type, repunit, collection, indiv, MixtureData, stringsAsFactors = FALSE)
  
  ##########################################################################
  
  ###################
  # Network Method
  ###################
  
  lambda = seq(0.4, 0.02, length.out=40)
  
  NeighborhoodSolPath = LASSOSolPath(Y, lambda=lambda, SampleSizeBaselinePop=SampleSizeBaselinePop, UseWeights = T) 
  
  ################################
  
  # Winner takes it all:
  
  NetworkResultsWTA = WTAInference(MBapprox=NeighborhoodSolPath,ReferenceData=ReferenceData,SampleNames=colnames(Y),
                                   SampleSizeBaselinePop=SampleSizeBaselinePop,NmbOfParents=1)
  
  MNetworkWTA = NetworkResultsWTA$ProbofOrigi
  
  MixPropWTA = colMeans(MNetworkWTA)
  
  ################################
  
  # Solution path approach:
  
  NetworkResultsSolpath = SolPathInference(MBapprox=NeighborhoodSolPath,ReferenceData=ReferenceData,
                                           SampleNames=colnames(Y),SampleSizeBaselinePop=SampleSizeBaselinePop, 
                                           alpha = NmbofOut/length(Mixture))
  
  MNetworkSolPath = NetworkResultsSolpath$ProbofOrigin
  MNetworkSolPath = MNetworkSolPath[ , -ncol(MNetworkSolPath)]
  
  MixPropSolPath = colMeans(MNetworkSolPath)
  
  ##########################################################################
  
  #############
  # ADMIXTURE
  #############
  
  cat("\n")
  
  G = t(Y)
  
  rownames(G) = as.character(1:nrow(G))
  
  #dim(G)
  
  ADMIXTUREResults = radmixtureEstimator(MixtureData, ReferenceData, G)
  
  MixPropADMIXTURE = colMeans(ADMIXTUREResults)
  
  ##########################################################################
  
  ##########
  # RUBIAS
  ##########
  
  RubiasReference = Convert2TwoColumnformat(ReferenceData[ ,-c(1:4)])
  
  RubiasReference = as.matrix(RubiasReference)
  
  storage.mode(RubiasReference) = "integer"
  
  RubiasReference = cbind(ReferenceData[ ,1:4], RubiasReference)
  
  ##
  
  RubiasMixture = Convert2TwoColumnformat(MixtureData[ ,-c(1:4)]) # Pre-modification of the data
  
  RubiasMixture = as.matrix(RubiasMixture)
  
  storage.mode(RubiasMixture) = "integer"
  
  RubiasMixture = cbind(MixtureData[ ,1:4], RubiasMixture)
  
  RubiasResults = infer_mixture(RubiasReference, RubiasMixture, 
                                gen_start_col=5, method = "MCMC", reps=1000) # The Rubias analysis part 
  
  RubiasPB = infer_mixture(reference = RubiasReference, 
                           mixture = RubiasMixture, 
                           gen_start_col = 5, method = "PB") # Bootstrap-corrected reporting unit proportions
  
  PofzRubias = RubiasResults$indiv_posteriors
  
  MRubias = matrix(PofzRubias$PofZ, 3, nrow(MixtureData))
  
  rownames(MRubias) = unique(PofzRubias$repunit)
  
  colnames(MRubias) = unique(PofzRubias$indiv)
  
  MRubias = t(MRubias)
  
  MRubias = MRubias[rownames(MNetworkSolPath), ] # Re-order rows
  
  RubiasPBTable = RubiasPB$bootstrapped_proportions
  
  MixPropRUBIASPB = RubiasPBTable$bs_corrected_repunit_ppn
  
  names(MixPropRUBIASPB) = RubiasPBTable$repunit
  
  ##########################################################################
  
  ############
  # AssignPOP 
  ############
  
  RefDataAssignPOP = ReferenceData[ ,c(4, 2, 5:ncol(ReferenceData))]
  
  colnames(RefDataAssignPOP)[1:2] = c("ID","pop")
  
  write.table(RefDataAssignPOP,"RefDataAssignPOP.txt", row.names = F, col.names = T, quote = F, na="-9")
  
  MixtureDataAssignPOP = MixtureData[ ,c(4, 2, 5:ncol(MixtureData))]
  
  colnames(MixtureDataAssignPOP) = colnames(RefDataAssignPOP)
  
  write.table(MixtureDataAssignPOP,"MixtureDataAssignPOP.txt", row.names = F, col.names = T, quote = F, na="-9")
  
  # Finally one can generate datafiles for genePOP. Note that genotype at one locus is a single column in
  # the input file of "read.Structure":
  
  RefDataAssignPOP = read.Structure("RefDataAssignPOP.txt", haploid=T) 
  MixtureDataAssignPOP = read.Structure("MixtureDataAssignPOP.txt", haploid = T)
  
  # Next is so the readline command in assign.X can be ignored:
  
  AssignPOPLoci = intersect(colnames(RefDataAssignPOP$DataMatrix), colnames(MixtureDataAssignPOP$DataMatrix))
  
  RefDataAssignPOP$DataMatrix = RefDataAssignPOP$DataMatrix[ ,AssignPOPLoci]
  
  MixtureDataAssignPOP$DataMatrix = MixtureDataAssignPOP$DataMatrix[ ,AssignPOPLoci]
  
  ####################################################
  
  # Now we can analyse the data with assignPOP. The default classifier is the support vector machine:
  
  trashSVM <- assign.X(x1=RefDataAssignPOP, x2=MixtureDataAssignPOP, dir="AssignPOPResultsSVM/", 
                       mplot=T, model="svm") 
  rm(trashSVM)
  
  trashNB <- assign.X(x1=RefDataAssignPOP, x2=MixtureDataAssignPOP, dir="AssignPOPResultsNB/",
                      mplot=T, model="naiveBayes") 
  rm(trashNB)
  
  ####################################################
  
  # AssignPOP results are in an external file:
  
  MAssignPOPSVM = read.table("AssignPOPResultsSVM/AssignmentResult.txt",header=T,stringsAsFactors = F,check.names = F)
  rownames(MAssignPOPSVM) = MAssignPOPSVM$Ind.ID
  MAssignPOPSVM = MAssignPOPSVM[ ,-c(1:2)]
  
  MixPropAssignPOPSVM = colMeans(MAssignPOPSVM[ ,colnames(MRubias)]) # Mixture proportions
  
  MAssignPOPSVM = MAssignPOPSVM[ ,colnames(MRubias)] # Order rows (populations) in the same order they are 
  # in RUBIAS files
  
  ##########
  
  MAssignPOPNB = read.table("AssignPOPResultsNB/AssignmentResult.txt",header=T,stringsAsFactors = F,check.names = F)
  rownames(MAssignPOPNB) = MAssignPOPNB$Ind.ID
  MAssignPOPNB = MAssignPOPNB[ ,-c(1:2)]
  
  MixPropAssignPOPNB = colMeans(MAssignPOPNB[ ,colnames(MRubias)]) # Mixture proportions
  
  MAssignPOPNB = MAssignPOPNB[ ,colnames(MRubias)] # Order rows (populations) in the same order they are 
  # in RUBIAS files
  
  ##########################################################################
  
  ##########################################################################
  
  TP[k] = length(intersect(names(NetworkResultsSolpath$OutgroupMembers), MixtureData$indiv[1:NmbofOut])) # Nmb of True positives
  
  FP[k] = length(setdiff(names(NetworkResultsSolpath$OutgroupMembers), MixtureData$indiv[1:NmbofOut])) # Nmb of False positives
  
  Results$Prob.origin.ADMIXTURE[k] = MSE(ADMIXTUREResults, Q[Mixture, -1])
  
  Results$Prob.origin.RUBIAS.MCMC[k] = MSE(MRubias, Q[Mixture, -1])
  
  Results$Prob.origin.AssignPOP.NB[k] = MSE(as.matrix(MAssignPOPNB), Q[Mixture, -1])
  Results$Prob.origin.AssignPOP.SVM[k] = MSE(as.matrix(MAssignPOPSVM), Q[Mixture, -1])
  
  Results$Prob.origin.Net.WTA[k] = MSE(MNetworkWTA, Q[Mixture, -1])
  Results$Prob.origin.Net.SolPath[k] = MSE(MNetworkSolPath, Q[Mixture, -1])
  
  ##
  
  Results$Mix.Prop.ADMIXTURE[k] = MSE(MixPropADMIXTURE, m/sum(m))
  
  Results$Mix.Prop.RUBIAS.MCMC[k] = MSE(RubiasResults$mixing_proportions$pi, m/sum(m)) # Rubias own procedures
  Results$Mix.Prop.RUBIAS.PB[k] = MSE(MixPropRUBIASPB, m/sum(m)) # Bootstrap corrected proportions
  
  Results$Mix.Prop.AssignPOP.NB[k] = MSE(MixPropAssignPOPNB, m/sum(m))
  Results$Mix.Prop.AssignPOP.SVM[k] = MSE(MixPropAssignPOPSVM, m/sum(m))
  
  Results$Mix.Prop.Net.WTA[k] = MSE(MixPropWTA, m/sum(m))
  Results$Mix.Prop.Net.SolPath[k] = MSE(MixPropSolPath, m/sum(m))
  
  ##
  
  AssignmentResults$ADMIXTURE[k] =  sum(apply(ADMIXTUREResults, 1, which.max)[-c(1:NmbofOut)] == 
                                          apply(Q[Mixture, -1], 1, which.max)[-c(1:NmbofOut)])
  
  AssignmentResults$RUBIAS[k] =  sum(apply(MRubias, 1, which.max)[-c(1:NmbofOut)] == 
                                       apply(Q[Mixture, -1], 1, which.max)[-c(1:NmbofOut)])
  
  AssignmentResults$AssignPOPNB[k] = sum(apply(MAssignPOPNB, 1, which.max)[-c(1:NmbofOut)] == 
                                           apply(Q[Mixture, -1], 1, which.max)[-c(1:NmbofOut)])
  AssignmentResults$AssignPOPSVM[k] = sum(apply(MAssignPOPSVM, 1, which.max)[-c(1:NmbofOut)] ==
                                            apply(Q[Mixture, -1], 1, which.max)[-c(1:NmbofOut)])
  
  AssignmentResults$Net.WTA[k] =  sum(apply(MNetworkWTA, 1, which.max)[-c(1:NmbofOut)] == 
                                        apply(Q[Mixture, -1], 1, which.max)[-c(1:NmbofOut)])
  AssignmentResults$Net.SolPath[k] =  sum(apply(MNetworkSolPath, 1, which.max)[-c(1:NmbofOut)] == 
                                            apply(Q[Mixture, -1], 1, which.max)[-c(1:NmbofOut)])
  
}

################################

# Remove rownames for so they are not displayed in the barplot plot:

rownames(MNetworkWTA) = NULL

rownames(MNetworkSolPath) = NULL

rownames(MRubias) = NULL

rownames(MAssignPOPSVM) = NULL

rownames(MAssignPOPNB) = NULL

################################

# Bayes methods and Winner takes it all method:

par(oma=c(3,3,0,0),mar=c(3,3,2,2),mfrow=c(4,1))

barplot(t(MRubias), col=c("#80FF00FF", "#00FFFFFF", "#8000FFFF"), main="RUBIAS (MCMC)", space=0, 
        yaxt="n", cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)

barplot(t(MAssignPOPNB), col=c("#80FF00FF", "#00FFFFFF", "#8000FFFF"), main="AssignPOP (naive Bayes)", space=0, 
        yaxt="n", cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)

barplot(t(MNetworkWTA), col=c("#80FF00FF", "#00FFFFFF", "#8000FFFF"), main="BONE (WTA)", space=0, 
        yaxt="n", cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)

barplot(t(Q[Mixture, ]), col=rainbow(4), main="True populations of origin", space=0, 
        yaxt="n", cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)

mtext(text="Prob. of origin",side=2,line=0,outer=TRUE,cex=1.5)

###########

par(oma=c(3,3,0,0),mar=c(3,3,2,2),mfrow=c(4,1))

barplot(t(MAssignPOPSVM), col=c("#80FF00FF", "#00FFFFFF", "#8000FFFF"), main="AssignPOP (support vector machine)", space=0, 
        yaxt="n", cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)

barplot(t(MNetworkSolPath), col=c("#80FF00FF", "#00FFFFFF", "#8000FFFF"), main="BONE (solution path)", space=0, 
        yaxt="n", cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)

# Mark potential outsiders with a star:

ETs = NetworkResultsSolpath$OutgroupMembers
ETs = as.vector(ETs)

MarkOutsiders = rep(NA, nrow(MNetworkSolPath))
MarkOutsiders[ETs] = "X"

#mids = barplot(t(MNetworkSolPath), xlab="", plot=F)
mids = 1:length(Mixture)

mids = mids-0.5

axis(1, at=mids, MarkOutsiders, tick=F, cex.axis=0.5)

#####

barplot(t(ADMIXTUREResults), col=c("#80FF00FF", "#00FFFFFF", "#8000FFFF"), main="ADMIXTURE", space=0, 
        yaxt="n", cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)

barplot(t(Q[Mixture, ]), col=rainbow(4), main="True populations of origin", space=0, 
        yaxt="n", cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)

mtext(text="Prob. of origin",side=2,line=0,outer=TRUE,cex=1.5)

###########

par(mfrow=c(1,1))

ProbOriginGuess = rep(0,M) # Are results better than random guessing?
MixPropGuess = rep(0,M)

for(i in 1:M){
  Quess = rdirichlet(ncol(MRubias), m/sum(m))
  Quess = as.vector(t(Quess))
  ProbOriginGuess[i] = MSE(Q[Mixture, -1], Quess)
  MixPropGuess[i] = MSE(m/sum(m), as.vector(gtools::rdirichlet(1, m/sum(m))))
}

Results = cbind(Results,ProbOriginGuess,MixPropGuess)

boxplot(Results[ ,c(1, 3, 6, 8, 10, 12, 14)], main="Probability of origin MSE")
boxplot(Results[ ,c(2, 4, 5, 7, 9, 11, 13, 15)], main="Mixing proportions MSE")

boxplot(Results[ ,c(1, 3, 6, 8, 10, 12)], main="Probability of origin MSE")
boxplot(Results[ ,c(2, 4, 5, 7, 9, 11, 13)], main="Mixing proportions MSE")

boxplot(Results[ ,c(2, 4, 7, 9, 11, 13)], main="Mixing proportions MSE")

###########

# How accurately were the outsiders detected?

mean(TP/NmbofOut) # True positive rate
sd(TP/NmbofOut) # True positive rate standard deviation

mean(TP/(TP + FP)) # Precision
sd((TP/(TP + FP))) # precision standard deviation

mean(FP/sum(m)) # False Positive Rate
sd(FP/sum(m)) # FPR standard deviation

###########

summary(AssignmentResults/sum(m)) # Percentages

###########

write.table(Results, "SimulationResultsMSE.txt", quote = F, row.names = F)

write.table(AssignmentResults, "SimulationResultsAssignment.txt", quote = F, row.names = F)

OutsiderDetection = cbind(TP,FP)

write.table(OutsiderDetection, "DetectedOutsiders.txt", quote = F, row.names = F)

#save.image()
