
# 20.06.2019

LASSOSolPath = function(Y, lambda, intercept=T, SampleSizeBaselinePop, UseWeights = F){
  
  L = nrow(Y)
  N = ncol(Y)
  
  p = N
  
  MBapprox = array(0,c(p,p,length(lambda)))
  
  k = 1
  
  MixInd = (SampleSizeBaselinePop + 1):N
  BaselineInd = 1:SampleSizeBaselinePop
  
  h = 1
  
  cat("Mixture","\n")
  
  for(i in MixInd){
    
    if(UseWeights){
      
      GenFreq = table(Y[ ,MixInd])/length(Y[ ,MixInd])
      
      weights = 1 - GenFreq[as.character(Y[ ,i])]
      
      weights = as.vector(weights)
     
      fit = glmnet(Y[ ,BaselineInd], Y[ ,i], intercept=intercept, lambda=lambda, family="multinomial", weights = weights)
       
    }else{
      
      fit = glmnet(Y[,BaselineInd], Y[,i],intercept=intercept, lambda=lambda, family="multinomial")
      
    }
    
    for(j in 1:length(lambda)){
      
      BetaNames = names(fit$beta)
      
      sarake = 0
      
      for(d in 1:length(BetaNames)){
        
        sarake = sarake + as.vector(abs(coef(fit)[[BetaNames[d]]][,j]))
        
      }
      
      #sarake = as.vector(abs(coef(fit)$"0"[,j]) + abs(coef(fit)$"1"[,j]) + abs(coef(fit)$"2"[,j]))
      
      MBapprox[BaselineInd,i,j] = sarake[-1]
      
    }
    
    cat("\r", round(h/length(MixInd)*100,2), "%")
    
    h = h + 1
    
  }
  
  # Then, explain baseline with mixture
  
  cat("\n")
  cat("Baseline","\n")
  
  for(i in BaselineInd){
    
    if(UseWeights){
      
      GenFreq = table(Y[ ,BaselineInd])/length(Y[ ,BaselineInd])
      
      weights = 1 - GenFreq[as.character(Y[ ,i])]
      
      weights = as.vector(weights)
      
      fit = glmnet(Y[ ,MixInd], Y[ ,i], intercept=intercept, lambda=lambda, family="multinomial", weights = weights)
      
    }else{
      
      fit = glmnet(Y[,MixInd], Y[,i],intercept=intercept,lambda=lambda,family="multinomial") 
      
    }
    
    for(j in 1:length(lambda)){
      
      BetaNames = names(fit$beta)
      
      rivi = 0
      
      for(d in 1:length(BetaNames)){
        
        rivi = rivi + as.vector(abs(coef(fit)[[BetaNames[d]]][,j]))
        
      }
      
      #rivi = as.vector(abs(coef(fit)$"0"[,j]) + abs(coef(fit)$"1"[,j]) + abs(coef(fit)$"2"[,j]))
      
      MBapprox[MixInd,i,j] = rivi[-1]
      
    }
    
    cat("\r", round(i/length(BaselineInd)*100,2), "%")
    
  }
  
  #########################################################
  
  #########################################################
  
  
  return(MBapprox) # Hox! Non-symmetric network!
  
}