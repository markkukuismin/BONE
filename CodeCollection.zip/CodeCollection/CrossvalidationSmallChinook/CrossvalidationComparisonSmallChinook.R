
# 14.08.2019

library(glmnet)
library(rubias)
library(gtools)
library(igraph)
library(assignPOP)
library(radmixture)
library(data.table)

# Load functions needed for the network inference method:

source("NetworkMethod/impute.R")
source("NetworkMethod/LASSOSolPath.R")
source("NetworkMethod/SolPathInference.R")
source("NetworkMethod/WTAInference.R")

# Load a function which makes data modifications and runs the (r)ADMIXTURE method:

source("radmixtureEstimator.R")

# Define the error function:

MSE = function(x,y){
  
  mean((x-y)^2)
  
}

#######################################################

N = 100 # Nmb of mixture individuals

M = 50 # Number of simulation rounds

Results = matrix(0,nrow=M,ncol=12)
colnames(Results) = c("Prob.origin.ADMIXTURE","Mix.Prop.ADMIXTURE",
                      "Prob.origin.RUBIAS.MCMC","Mix.Prop.RUBIAS.MCMC",
                      "Prob.origin.Net.WTA","Mix.Prop.Net.WTA",
                      "Prob.origin.Net.SolPath","Mix.Prop.Net.SolPath",
                      "Prob.origin.AssignPOP.SVM","Mix.Prop.AssignPOP.SVM",
                      "Prob.origin.AssignPOP.NB","Mix.Prop.AssignPOP.NB")

ModifiedSNPs = matrix(0,nrow=M,ncol=3)
colnames(ModifiedSNPs) = c("Removed","Mono","Imputed")

#######################################################

# Define the mixture proportions:

table(small_chinook_ref$repunit)
rhos = as.vector(gtools::rdirichlet(1, table(small_chinook_ref$repunit)))
names(rhos) = names(table(small_chinook_ref$repunit))

# The expected value of "rhos" is

table(small_chinook_ref$repunit)/sum(table(small_chinook_ref$repunit))
rhos

for(k in 1:M){
  
  # Simulate data with RUBIAS:
  
  cross_val = mixture_draw(D = small_chinook_ref, rhos = rhos, N = N, min_remaining = .005) # Simulate data
  
  MixtureData = cross_val$mixture
  ReferenceData = cross_val$reference # There are "number of original baseline samples" - N samples in the reference file - about. See "min_remaining"

  ReferenceData[ReferenceData == 5] = NA  
  MixtureData[MixtureData == 5] = NA
  
  ########
  # RUBIAS
  ########
  
  #############################
  # Analyse the simulated data:
  #############################
  
  mcmc = infer_mixture(reference=ReferenceData,mixture=MixtureData,gen_start_col=5,method = "MCMC",reps=1000)
  #pb = infer_mixture(reference=ReferenceData,mixture=MixtureData,gen_start_col=5,method = "PB",reps=1000,pb_iter = 100)
  
  # RUBIAS with bootstrapping only corrects the mixture proportions...
  
  ############################################################################
  
  MixingPropMCMC = mcmc$mixing_proportions # These are the mixing proportions
  IndivProbsMCMC = mcmc$indiv_posteriors # These are the posterior estimates of the probability of the origin
  
  ############################################################################
  
  # Reorder individuals in the probability of the origin table in the same order as they appear in the 
  # original mixture data file:
  
  NewOrder = matrix(0,length(rhos),nrow(MixtureData))
  
  for(i in 1:nrow(MixtureData)){
    
    NewOrder[,i] = which(IndivProbsMCMC$indiv == MixtureData$indiv[i])
    
  }
  
  NewOrder = as.vector(NewOrder)
  
  IndivProbsMCMC = IndivProbsMCMC[NewOrder,] # Finally, order data according to how individuals appear in 
  # the mixture data file
  
  MixtureSmaller = MixtureData[,2:4] # Just to make working with the table easier
  
  MixtureTruth = data.frame(repunit=IndivProbsMCMC$repunit,indiv=IndivProbsMCMC$indiv,PofZ=rep(0,nrow(IndivProbsMCMC)),
                            stringsAsFactors = F)
  
  MixtureSmaller = as.data.frame(MixtureSmaller) # Tables aren't exactly the same but now they are
  
  Ind = matrix(1:nrow(MixtureTruth),nrow=length(rhos)) # Indicator variable to find rows of one individuals
  
  # Finally, set "PopZ" to the "true" value, in other words to 1:
  
  for(j in 1:ncol(Ind)){
    
    i = which(MixtureTruth$repunit[Ind[,j]] == MixtureSmaller$repunit[j])
    MixtureTruth[Ind[i,j],3] = 1 
    
  }
  
  ##########################################################################
  ##########################################################################
  
  ############
  # AssignPOP 
  ############
  
  RefDataAssignPOP = ReferenceData[ ,c(4, 2, 5:ncol(ReferenceData))]
  
  colnames(RefDataAssignPOP)[1:2] = c("ID","pop")
  
  #A = RefDataAssignPOP[ ,c(1,2, seq(3, ncol(RefDataAssignPOP), by=2))]
  #B = RefDataAssignPOP[ ,c(1,2, seq(4, ncol(RefDataAssignPOP), by=2))]
  
  #RefDataAssignPOP = rbind(A, A)
  
  #RefDataAssignPOP[seq(1, nrow(RefDataAssignPOP) - 1, by=2), ] = A
  #RefDataAssignPOP[seq(2, nrow(RefDataAssignPOP), by=2), ] = B
  
  write.table(RefDataAssignPOP,"RefDataAssignPOP.txt", row.names = F, col.names = T, quote = F, na="-9")
  
  MixtureDataAssignPOP = MixtureData[ ,c(4, 2, 5:ncol(MixtureData))]
  
  colnames(MixtureDataAssignPOP) = colnames(RefDataAssignPOP)
  
  #A = MixtureDataAssignPOP[ ,c(1,2, seq(3, ncol(MixtureDataAssignPOP), by=2))]
  #B = MixtureDataAssignPOP[ ,c(1,2, seq(4, ncol(MixtureDataAssignPOP), by=2))]
  
  #MixtureDataAssignPOP = rbind(A, A)
  
  #MixtureDataAssignPOP[seq(1, nrow(MixtureDataAssignPOP), by=2), ] = A
  #MixtureDataAssignPOP[seq(2, nrow(MixtureDataAssignPOP), by=2), ] = B
  
  write.table(MixtureDataAssignPOP,"MixtureDataAssignPOP.txt", row.names = F, col.names = T, quote = F, na="-9")
  
  # Finally one can generate datafiles for genePOP:
  
  #RefDataAssignPOP = read.Structure("RefDataAssignPOP.txt", haploid=F) 
  #MixtureDataAssignPOP = read.Structure("MixtureDataAssignPOP.txt", haploid = F)
  
  # Fluidigm genotyping: read in as halpoids:
  
  RefDataAssignPOP = read.Structure("RefDataAssignPOP.txt", haploid=T) 
  MixtureDataAssignPOP = read.Structure("MixtureDataAssignPOP.txt", haploid = T)
  
  # Next is that the readline command in assign.X can be ignored:
  
  AssignPOPLoci = intersect(colnames(RefDataAssignPOP$DataMatrix), colnames(MixtureDataAssignPOP$DataMatrix))
  
  RefDataAssignPOP$DataMatrix = RefDataAssignPOP$DataMatrix[ ,AssignPOPLoci]
  
  MixtureDataAssignPOP$DataMatrix = MixtureDataAssignPOP$DataMatrix[ ,AssignPOPLoci]
  
  ####################################################
  
  # Now we can analyse the data with assignPOP. The default classifier is the support vector machine:
  
  # Tahan jain. Tulokset eivat ole loogisia... Joku inputissa mattaa...
  
  trashSVM <- assign.X(x1=RefDataAssignPOP, x2=MixtureDataAssignPOP, dir="AssignPOPResultsSVM/", 
                       mplot=T, model="svm") 
  rm(trashSVM)
  
  trashNB <- assign.X(x1=RefDataAssignPOP, x2=MixtureDataAssignPOP, dir="AssignPOPResultsNB/",
                      mplot=T, model="naiveBayes") 
  rm(trashNB)
  
  ####################################################
  
  # AssignPOP results are in an external file:
  
  MAssignPOPSVM = read.table("AssignPOPResultsSVM/AssignmentResult.txt",header=T,stringsAsFactors = F,check.names = F)
  rownames(MAssignPOPSVM) = MAssignPOPSVM$Ind.ID
  MAssignPOPSVM = t(MAssignPOPSVM[,3:ncol(MAssignPOPSVM)])
  
  MixPropAssignPOPSVM = rowMeans(MAssignPOPSVM[names(table(small_chinook_ref$repunit)),]) # Mixture proportions
  
  MAssignPOPSVM = MAssignPOPSVM[IndivProbsMCMC$repunit[1:length(rhos)],] # Order rows (populations) in the same order they are 
  # in RUBIAS files
  
  ##########
  
  MAssignPOPNB = read.table("AssignPOPResultsNB/AssignmentResult.txt",header=T,stringsAsFactors = F,check.names = F)
  rownames(MAssignPOPNB) = MAssignPOPNB$Ind.ID
  MAssignPOPNB = t(MAssignPOPNB[,3:ncol(MAssignPOPNB)])
  
  MixPropAssignPOPNB = rowMeans(MAssignPOPNB[names(table(small_chinook_ref$repunit)),]) # Mixture proportions
  
  MAssignPOPNB = MAssignPOPNB[IndivProbsMCMC$repunit[1:length(rhos)],] # Order rows (populations) in the same order they are 
  # in RUBIAS files
  
  ##########################################################################
  ##########################################################################
  
  ################
  # ADMIXTURE
  ################
  
  ADMIXTUREData = rbind(ReferenceData, MixtureData)
  
  ADMIXTUREData = ADMIXTUREData[ ,-c(1:4)]
  
  ADMIXTUREData[is.na(ADMIXTUREData)] = 0
  
  A = data.frame(V1 = rep(1, nrow(ADMIXTUREData)), V2 = c(ReferenceData$indiv, MixtureData$indiv), 
                 V3 = c(ReferenceData$indiv, MixtureData$indiv), V4 = c(ReferenceData$indiv, MixtureData$indiv), 
                 V5 = rep(0, nrow(ADMIXTUREData)), V6 = rep(-9, nrow(ADMIXTUREData)), stringsAsFactors = F)
  
  ADMIXTUREData = cbind(A, ADMIXTUREData)
  
  ADMIXTUREData = as.data.frame(ADMIXTUREData)
  
  # There are too many missing genotypes. Impute them with random selection of genotype based on the allele frequencies
  # across the entire baseline
  
  A = as.matrix(ReferenceData[ ,-c(1:4)])
  
  GenotypeFreq = table(A)
  
  GenotypeFreq = GenotypeFreq[names(GenotypeFreq) != 0]
  
  prob = GenotypeFreq/sum(GenotypeFreq)
  
  b = sum(ADMIXTUREData == 0)
  
  #ADMIXTUREData[ADMIXTUREData == 0] = sample(as.numeric(names(GenotypeFreq)), b, prob=prob, replace = T) # Does not work...
  
  ADMIXTUREData[ADMIXTUREData == 0] = as.numeric(names(GenotypeFreq))[which.max(GenotypeFreq)]
  
  ADMIXTUREData$V5 = 0
  
  ADMIXTUREData = as.data.frame(ADMIXTUREData)
  
  MADMIXTURE = radmixtureEstimator(as.data.frame(MixtureData), as.data.frame(ReferenceData), ADMIXTUREData) # No tibble format
  
  rownames(MADMIXTURE) = MixtureData$indiv
  
  MADMIXTURE =  MADMIXTURE[ ,rownames(MAssignPOPSVM)]
  
  MixPropADMIXTURE = colMeans(MADMIXTURE[ ,names(table(small_chinook_ref$repunit))])
  
  ##########################################################################
  ##########################################################################
  
  ################
  # Network method
  ################
  
  MixtureY = impute(MixtureData, genotyping = "Fluidigm")
  ReferenceY = impute(ReferenceData, genotyping = "Fluidigm")
  
  ModifiedSNPs[k,] = MixtureY$Removed + ReferenceY$Removed
  
  MixtureY = MixtureY$Y
  ReferenceY = ReferenceY$Y
  
  # Choose only same set of markers:
  setdiff(rownames(MixtureY),rownames(ReferenceY))
  Markers = intersect(rownames(MixtureY),rownames(ReferenceY))
  
  MixtureY = MixtureY[Markers,]
  ReferenceY = ReferenceY[Markers,]
  
  SampleSizeBaselinePop = ncol(ReferenceY)
  
  Y = cbind(ReferenceY,MixtureY)
  
  rm(list=c("ReferenceY","MixtureY"))
  
  #####
  
  lambda = seq(0.4,0.02,length.out=40)
  
  NeighborhoodSolPath = LASSOSolPath(Y, lambda=lambda, SampleSizeBaselinePop=SampleSizeBaselinePop, UseWeights = T) 
  
  # Hox! Non-symmetric network!
  save(NeighborhoodSolPath,file="NetworkMethod/SolutionPathBasAndMixNonSymmetricMBapprox.RData")
  
  ################################
  
  # Winner takes it all approach:
  
  NetworkResultsWTA = WTAInference(MBapprox=NeighborhoodSolPath,ReferenceData=ReferenceData,SampleNames=colnames(Y),
                                   SampleSizeBaselinePop=SampleSizeBaselinePop,NmbOfParents=1) #(*)
  
  ExpendapleM = NetworkResultsWTA$ProbofOrigi
  ExpendapleM = as.vector(t(ExpendapleM))
  
  NetworkIndivPofzWTA = data.frame(indiv=rep(MixtureSmaller$indiv,each=length(rhos)),PofZ=ExpendapleM,
                                   repunit = sort(unique(ReferenceData$repunit)),stringsAsFactors = F)
  
  # Individuals are in this order because of the function "rowsums" used in the function above (*)
  
  # Individuals should be in the same order:
  
  if(!all.equal(IndivProbsMCMC$indiv,NetworkIndivPofzWTA$indiv)){
    stop("Error: Individuals are out of order!") 
  }
  
  # Still need to arrange them according to the population names:
  
  a = seq(0,nrow(IndivProbsMCMC)-length(rhos),by=length(rhos))
  a = rep(a,each=length(rhos))
  
  a = match(IndivProbsMCMC$repunit,NetworkIndivPofzWTA$repunit) + a
  
  NetworkIndivPofzWTA = NetworkIndivPofzWTA[a, ]
  
  if(!all.equal(IndivProbsMCMC$repunit,NetworkIndivPofzWTA$repunit)){
    stop("Error: Populations are not in comparabel order!")
  }
  
  ################################
  
  # Solution path approach:
  
  NetworkResultsSolpath = SolPathInference(MBapprox=NeighborhoodSolPath,ReferenceData=ReferenceData,
                                           SampleNames=colnames(Y),SampleSizeBaselinePop=SampleSizeBaselinePop) #(*)
  
  ExpendapleM = NetworkResultsSolpath$ProbofOrigin
  ExpendapleM = as.vector(t(ExpendapleM[,-ncol(ExpendapleM)]))
  
  NetworkIndivPofzSolPath = data.frame(indiv=rep(MixtureSmaller$indiv,each=length(rhos)),PofZ=ExpendapleM,
                                       repunit = sort(unique(ReferenceData$repunit)),stringsAsFactors = F)
  
  # Individuals are in this order because of the function "rowsum" used in the function above (*)
  
  # Individuals should be in the same order:
  
  if(!all.equal(IndivProbsMCMC$indiv,NetworkIndivPofzSolPath$indiv)){
    stop("Error: Individuals are out of order!") 
  }
  
  # Still need to arrange them according to the population names:
  
  NetworkIndivPofzSolPath = NetworkIndivPofzSolPath[a, ]
  
  if(!all.equal(IndivProbsMCMC$repunit,NetworkIndivPofzSolPath$repunit)){
    stop("Error: Populations are not in comparabel order!")
  }
  
  ##########################################################################
  ##########################################################################
  
  MixingPropRUBIASMCMC = by(IndivProbsMCMC$PofZ,IndivProbsMCMC$repunit,mean) # Not the right way but 
  # produces smaller MSE...
  
  Results[k,1] = MSE(as.vector(t(MADMIXTURE[ ,unique(MixtureTruth$repunit)])),MixtureTruth$PofZ) # Prob. of origin ADMIXTURE
  # supervised learning
  Results[k,2] = MSE(MixPropADMIXTURE,rhos) # Mixture proportions, ADMIXTURE supervised learning
  
  Results[k,3] = MSE(IndivProbsMCMC$PofZ,MixtureTruth$PofZ) # Prob. of origin RUBIAS (MCMC) (**)
  Results[k,4] = MSE(MixingPropRUBIASMCMC,rhos) # Mixture proportions RUBIAS (MCMC) (**)
  
  Results[k,5] = MSE(NetworkIndivPofzWTA$PofZ,MixtureTruth$PofZ) # Prob. of origin Network WTA
  Results[k,6] = MSE(NetworkResultsWTA$MixtureProp,rhos) # Mixture proportions, Network WTA
  
  Results[k,7] = MSE(NetworkIndivPofzSolPath$PofZ,MixtureTruth$PofZ) # Prob. of origin Network solution path
  Results[k,8] = MSE(NetworkResultsSolpath$MixtureProp,rhos) # Mixture proportions, Network solution path
  
  Results[k,9] = MSE(as.vector(MAssignPOPSVM),MixtureTruth$PofZ) # Prob. of origin assignPOP (SVM)
  Results[k,10] = MSE(MixPropAssignPOPSVM,rhos) # Mixture proportions, assignPOP (SVM)
  
  Results[k,11] = MSE(as.vector(MAssignPOPNB),MixtureTruth$PofZ) # Prob. of origin assignPOP (naive Bayes)
  Results[k,12] = MSE(MixPropAssignPOPNB,rhos) # Mixture proportions, assignPOP (naive Bayes)
  
}

# Plot barplots of the prob. of origin:

# Plot barplots of the prob. of origin:

MRUBIASMCMC = matrix(IndivProbsMCMC$PofZ,nrow=length(rhos),ncol=nrow(MixtureData))

rownames(MRUBIASMCMC) = unique(IndivProbsMCMC$repunit)
colnames(MRUBIASMCMC) = unique(IndivProbsMCMC$indiv)

#Reorder columns and rows:

MADMIXTURE = MADMIXTURE[, rownames(MRUBIASMCMC) ]
MADMIXTURE = MADMIXTURE[colnames(MRUBIASMCMC), ]

############################

MNetworkWTA = matrix(NetworkIndivPofzWTA$PofZ,nrow=length(rhos),ncol=nrow(MixtureData))
MNetworkSolPath = matrix(NetworkIndivPofzSolPath$PofZ,nrow=length(rhos),ncol=nrow(MixtureData))

############################

MTrue = matrix(MixtureTruth$PofZ,nrow=length(rhos),ncol=nrow(MixtureData))

colnames(MAssignPOPNB) = NULL
colnames(MAssignPOPSVM) = NULL

rownames(MADMIXTURE) = NULL

colnames(MRUBIASMCMC) = NULL

####################################

# Bayes methods and Winner takes it all method:

par(oma=c(3,3,0,0),mar=c(3,3,2,2),mfrow=c(4,1))

barplot(MRUBIASMCMC, col = rainbow(length(rhos)), space = 0,
        xlab = NULL, ylab = NULL,
        main="RUBIAS (MCMC)",yaxt="n",cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)
#abline(h=0.5, lty=2)

barplot(MAssignPOPNB, col = rainbow(length(rhos)), space = 0,
        xlab = NULL, ylab = NULL,
        main="AssignPOP (naive Bayes)",yaxt="n",cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)
#abline(h=0.5, lty=2)

barplot(MNetworkWTA, col = rainbow(length(rhos)), space = 0,
        xlab = NULL, ylab = NULL,
        main="BONE (WTA)",yaxt="n",cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)
#abline(h=0.5, lty=2)

barplot(MTrue, col = rainbow(length(rhos)), space = 0,
        xlab = "Individuals", ylab = NULL,
        main="Original Baseline",yaxt="n",cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)
#abline(h=0.5, lty=2)

mtext(text="Prob. of origin",side=2,line=0,outer=TRUE,cex=1.5)

text(y + 4,-0.05, srt = 1, adj= 1.1, xpd = TRUE,labels = unique(MixtureData$repunit), cex=1.1)

####################################

x = table(MixtureData$repunit); x = as.vector(x)
y = x/2
x = c(0,x[-length(x)]); x = cumsum(x)
y = y + x

text(y + 4,-0.05, srt = 1, adj= 1.1, xpd = TRUE,labels = unique(MixtureData$repunit), cex=1.1)

####################################

# ADMIXTURE, Parametric bootstarp, support vector machine and network solution path methods:

par(oma=c(3,3,0,0),mar=c(3,3,2,2),mfrow=c(4,1))

barplot(MAssignPOPSVM, col = rainbow(length(rhos)), space = 0,
        xlab = NULL, ylab = NULL,
        main="AssignPOP (support vector machine)",yaxt="n", cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)

barplot(MNetworkSolPath, col = rainbow(length(rhos)), space = 0,
        xlab = NULL, ylab = "Prob. of origin",
        main="BONE (solution path)",yaxt="n", cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)

# Potential outgroup memebers:

ETs = NetworkResultsSolpath$OutgroupMembers
ETs = as.vector(ETs)

text(ETs,-0.07, adj=1,xpd = TRUE,labels = c("*"), cex=3) # Potential outgroup members marked with a star

######################

barplot(t(MADMIXTURE), col = rainbow(length(rhos)), space = 0,
        xlab = NULL, ylab = NULL,
        main="ADMIXTURE",yaxt="n", cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)

barplot(MTrue, col = rainbow(length(rhos)), space = 0,
        xlab = "Individuals", ylab = "Prob. of origin",
        main="Original Baseline",yaxt="n", cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)
#abline(h=0.5, lty=2)

mtext(text="Prob. of origin",side=2,line=0,outer=TRUE,cex=1.5)

text(y + 4,-0.05, srt = 1, adj= 1.1, xpd = TRUE,labels = unique(MixtureData$repunit), cex=1.1)

####################################

# Save both figures as pdf, eps and tiff: landscape, a4 landscape. tiff & eps: 794 x 1123 pixels (a4 size)
# Name "ProbOriginBarplot". Smaller figure height 650 pixels and 6.5 inches.

######################

table(MixtureData$repunit)/sum(table(MixtureData$repunit)) # Empirical mixture proportions
rhos # Simulation model mixture proportions

par(mfrow=c(1,1))

ProbOriginGuess = rep(0,M) # Are results better than random guessing?
MixPropGuess = rep(0,M)

for(i in 1:M){
  Q = rdirichlet(ncol(MRUBIASMCMC), table(small_chinook_ref$repunit))
  Q = as.vector(t(Q))
  ProbOriginGuess[i] = MSE(Q,MixtureTruth$PofZ)
  MixPropGuess[i] = MSE(rhos,as.vector(gtools::rdirichlet(1, rhos)))
}

Results = cbind(Results,ProbOriginGuess,MixPropGuess)

boxplot(Results[,c(1,3,5,7,9,11,13)],main="Probability of origin MSE")
boxplot(Results[,c(2,4,6,8,10,12,14)],main="Mixing proportions MSE")

boxplot(Results[,c(1,3,5,7,9,11)],main="Probability of origin MSE")
boxplot(Results[,c(2,4,6,8,10,12)],main="Mixing proportions MSE")

###########################################################

write.table(Results,"SimulationResults.txt",quote=F)

write.table(MTrue,"MTrue.txt")

write.table(MRUBIASMCMC,"MRUBIASMCMC.txt")

write.table(t(MADMIXTURE),"MADMIXTURE.txt")

write.table(MAssignPOPNB,"MAssignPOPNB.txt")
write.table(MAssignPOPSVM,"MAssignPOPSVM.txt")

write.table(MNetworkWTA,"MNetworkWTA.txt")
write.table(MNetworkSolPath,"MNetworkSolPath.txt")

###########################################################

# Plot the solution path of one potential outgroup member and some other mixture individual
# to demonstrate the difference between LASSO solution paths:

ETs = NetworkResultsSolpath$OutgroupMembers
ET = sample(ETs,1)

NoET = NetworkResultsSolpath$ProbofOrigin
NoET = order(NoET[ ,ncol(NoET)],decreasing = T)[1:ncol(NoET)]
NoET = sample(NoET,1)
MixtureSmaller[NoET,]
names(NoET) = MixtureSmaller$indiv[NoET]

length(lambda)

Classes = IndivProbsMCMC$repunit[1:length(rhos)]

b = length(Classes)
NmbOfNeighbors = NetworkResultsSolpath$NmbOfNeighbors

# rows are in order: 

sort(unique(ReferenceData$repunit))

rownames(NmbOfNeighbors) = sort(unique(ReferenceData$repunit))

# Reorder rows, just that colors are in logical order compared to the barplots plotted before:

NmbOfNeighbors = NmbOfNeighbors[IndivProbsMCMC$repunit[1:length(rhos)],,]

#############################

LineColors = rainbow(b)

pdf("SolutionPathOutsiderInsider.pdf", paper="a4r")
par(mfrow=c(2,1))

for(i in 1:nrow(NmbOfNeighbors)){
  
  if(i == 1) plot(1:length(lambda), NmbOfNeighbors[i,ET, ], col=LineColors[i], ylim=c(0,max(NmbOfNeighbors[,ET,])), 
                  xlab="lambda", ylab="Nmb of neighbors", type="l", cex.axis=0.8, lwd=1.5,
                  main=paste("Potential outsider, weak genetic connection (id",names(ET),")",sep=" "), las=1)
  
  if(i > 1) lines(1:length(lambda), NmbOfNeighbors[i,ET, ], col=LineColors[i], lwd=1.5)
  
}

for(i in 1:nrow(NmbOfNeighbors)){
  
  if(i == 1) plot(1:length(lambda), NmbOfNeighbors[i,NoET, ], col=LineColors[i], ylim=c(0,max(NmbOfNeighbors[,NoET,])), 
                  xlab="lambda", ylab="Nmb of neighbors", type="l", cex.axis=0.8, lwd=1.5,
                  main=paste("Random individual, strong genetic connection (id",names(NoET),")",sep=" "), las=1)
  
  if(i > 1) lines(1:length(lambda), NmbOfNeighbors[i,NoET, ], col=LineColors[i], lwd=1.5)
  
}

dev.off()

##########

pdf("SolutionPathOutsider.pdf", paper="a4r")
par(mfrow=c(2,2),oma = c(0, 0, 2, 0))

for(i in 1:length(lambda)){
  
  barplot(NmbOfNeighbors[,ET,i],col=rainbow(b),names.arg=Classes,
          ylim=c(0,max(NmbOfNeighbors[,ET,])),main=paste("lambda",i),cex.names = 0.5)
  
  if(i %% 4 == 0) mtext(paste("Potential outsider, weak genetic connection (id",names(ET),")",sep=" "), outer = T, cex = 1.5)
  
}

dev.off()

pdf("SolutionPathInGroup.pdf", paper="a4r")
par(mfrow=c(2,2),oma = c(0, 0, 2, 0))

for(i in 1:length(lambda)){
  
  barplot(NmbOfNeighbors[,NoET,i],col=rainbow(b),names.arg=Classes,
          ylim=c(0,max(NmbOfNeighbors[,NoET,])),main=paste("lambda",i),cex.names = 0.5)
  
  if(i %% 4 == 0) mtext(paste("Random individual, strong genetic connection (id",names(NoET),")",sep=" "), outer = T, cex = 1.2)
  
}

dev.off()

save.image()
#Workspace is in file ".RData"
#load(".RData")


# How many SNPs were removed and imputed in average?

apply(ModifiedSNPs,2,mean)/2000 # Include SNPs twice: both mixture and baseline data

