
# 03.09.2019

library(ggplot2)
library(reshape)
library(gridExtra)

Results = read.table("SimulationResults.txt",header=T)

ResultsProbOrigin = Results[,c(1,3,5,7,9,11)]
colnames(ResultsProbOrigin) = c("ADMIXTURE","Rubias","BONE WTA", "BONE SP",
                                "AssignPOP SVM","AssignPOP nB")

ResultsMixProp = Results[,c(2,4,6,8,10,12)]
colnames(ResultsMixProp) = c("ADMIXTURE","Rubias","BONE WTA", "BONE SP",
                             "AssignPOP SVM","AssignPOP nB")

# The mixture proportions for the guessing are way too big for nice boxplots...

MeltData = melt(ResultsProbOrigin)
colnames(MeltData) = c("Method","MSE")

BoxplotProbOrigin = ggplot(MeltData) +
  geom_boxplot(aes(x=Method, y=MSE)) +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=12,face="bold")) + 
  ggtitle("Probability of the origin estimates") +
  labs(y="MSE\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

plot(BoxplotProbOrigin)

median(Results$ProbOriginGuess)
sd(Results$ProbOriginGuess)

MeltData = melt(ResultsMixProp)
colnames(MeltData) = c("Method","MSE")

BoxplotMixProp = ggplot(MeltData) +
  geom_boxplot(aes(x=Method, y=MSE)) +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=12,face="bold")) + 
  ggtitle("Mixture proportion estimates") +
  labs(y=NULL) +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

plot(BoxplotMixProp)

median(Results$MixPropGuess)
sd(Results$MixPropGuess)

grid.arrange(BoxplotProbOrigin,BoxplotMixProp,ncol=2)

#############################

scale = 0.8
pdf("ProbabOriginAndMixtureProp.pdf", width = 15*scale, height = 5*scale)
grid.arrange(BoxplotProbOrigin,BoxplotMixProp,ncol=2)
dev.off()



#############################

# Test if results significantly better

###################

# Probability of the origin:

t.test(ResultsProbOrigin$Rubias,ResultsProbOrigin$`BONE WTA`)
t.test(ResultsProbOrigin$Rubias,ResultsProbOrigin$`BONE (SP)`)
t.test(ResultsProbOrigin$Rubias,ResultsProbOrigin$`AssignPOP SVM`)
t.test(ResultsProbOrigin$Rubias,ResultsProbOrigin$`AssignPOP nB`)

t.test(ResultsProbOrigin$`BONE WTA`,ResultsProbOrigin$`BONE (SP)`)
t.test(ResultsProbOrigin$`BONE WTA`,ResultsProbOrigin$`AssignPOP SVM`)
t.test(ResultsProbOrigin$`BONE WTA`,ResultsProbOrigin$`AssignPOP nB`)

t.test(ResultsProbOrigin$`BONE Sol.path`,ResultsProbOrigin$`AssignPOP SVM`)

# No significant difference between Rubias, BONE WTA or AssignPOP methods: On average same results

# Only significant difference between BONE sol. path and others  => BONE sol. path MSE the smallest

###################

# Mixture proportions:

sort(apply(ResultsMixProp,2,var))

t.test(ResultsMixProp$Rubias,ResultsMixProp$`BONE WTA`) # (1)
t.test(ResultsMixProp$Rubias,ResultsMixProp$`BONE (SP)`) # (2)
t.test(ResultsMixProp$Rubias,ResultsMixProp$`AssignPOP SVM`) # (3)
t.test(ResultsMixProp$Rubias,ResultsMixProp$`AssignPOP nB`) # (4)

t.test(ResultsMixProp$`BONE WTA`,ResultsMixProp$`BONE (SP)`) # (5)
t.test(ResultsMixProp$`BONE WTA`,ResultsMixProp$`AssignPOP SVM`) # (6)

t.test(ResultsMixProp$`BONE Sol.path`,ResultsMixProp$`AssignPOP SVM`) # (7)


# Significant difference between Rubias and BONE WTA (WTA smaller mean) (1)
# Significant difference between Rubias and BONE sol. path (2)
# Significant difference between Rubias and AssignPOP SVM (SVM smaller mean) (3)
# Significant difference between BONE methods (5)
# Significant difference between network WTA and AssignPOP SVM (6)

# No significant difference between network Sol. path and AssignPOP SVM (7)
# No significant difference between Rubias and AssignPOP nB (4)
