
# 19.11.2018

SolPathInference = function(MBapprox,ReferenceData,SampleNames,SampleSizeBaselinePop,alpha=0.05){
  
  p = ncol(MBapprox[,,1]) # Total number of samples
  
  lambdalength = dim(MBapprox)[3]
  
  SampleSizeMixPop = p - SampleSizeBaselinePop
  
  MixInd = (SampleSizeBaselinePop + 1):p
  BaselineInd = 1:SampleSizeBaselinePop
  
  AllMixConnected = matrix(0,nrow=SampleSizeMixPop,ncol=lambdalength)
  
  lambda = NULL
  
  for(i in 1:lambdalength){
    lambda[i] = paste("lambda",i,sep="") # lambda_1 > lambda_2 > ... lambda_lambdalength
  }
  
  colnames(AllMixConnected) = lambda
  rownames(AllMixConnected) = SampleNames[MixInd]
  
  AllpsiLambda = array(0,c(p,p,lambdalength))
  
  SamplesBaseline = SampleNames[BaselineInd]
  SamplesMix = SampleNames[MixInd]
  
  for(index in 1:lambdalength){
    
    NewMBapprox2 = MBapprox[,,index]
    
    colnames(NewMBapprox2) = SampleNames
    rownames(NewMBapprox2) = SampleNames
    
    NewMBapprox2 = as.matrix(NewMBapprox2)
    
    NewMBapprox2 = NewMBapprox2*t(NewMBapprox2)
    
    psiLambda = ifelse(NewMBapprox2 != 0 , 1, 0)
    
    ###############################################################################
    
    AllMixConnected[,index] = colSums(psiLambda[BaselineInd,MixInd])
    
    AllpsiLambda[,,index] = psiLambda
    
  }
  
  # Determine the probability of the origin for each individual from the LASSO solution path
  
  b = length(unique(ReferenceData$repunit)) # nmb of classes
  
  Freq = array(0,c(b,SampleSizeMixPop,lambdalength)) # How many neighbors individual has with baseline populations
                                                     # given lambda
  
  dimnames(Freq)[[2]] = colnames(psiLambda)[MixInd]
  
  for(index in 1:lambdalength){
    
    Freq[,,index] = rowsum(AllpsiLambda[BaselineInd,MixInd,index],ReferenceData$repunit)
    
  }
  
  # Populations are in order: 
  
  #sort(unique(ReferenceData$repunit))
  
  # H_0: {Baseline frequencies}
  
  prob = c(table(ReferenceData$repunit)/SampleSizeBaselinePop)
  
  classes = sort(unique(ReferenceData$repunit))
  
  # How many times the neighborhood was present over different penalizations?
  
  Proportion = matrix(0,SampleSizeMixPop,b)
  
  colnames(Proportion) = classes
  rownames(Proportion) = SamplesMix
  
  # Determine a weighted average: larger lambda values (heavier penalization) have larger weights:
  
  w = lambdalength:1
  w = w/sum(w)
  
  for(i in 1:lambdalength){
    
    Proportion = Proportion + t(w[i]*Freq[,,i]) # (conditional) Weighted mean/frequency (given baseline populations)
    
  }
  
  RelProportion = apply(Proportion,1,function(x) x/sum(x)) # Standardized weighted frequencies
  
  RelProportion = t(RelProportion)
  
  DifferenceProportion = sweep(RelProportion,2,prob)
  
  DifferenceProportion = apply(DifferenceProportion,1,function(x) sum(x^2)/length(x))
  
  RelProportion = cbind(RelProportion,DifferenceProportion)
  
  #quantile(DifferenceProportion,probs = alpha) # The lower quantile of the squared differences
  
  Outsiders = which(DifferenceProportion < quantile(DifferenceProportion,probs = alpha))
  
  # Write probability of the origin results into a table:
  
  write.table(RelProportion,"NetworkMethod/RelProbOfOrigin.txt",quote = F)
  
  # Determine also the mixing proportions:
  
  EstimatedMixProp = apply(RelProportion[,1:b],2,as.numeric)
  rownames(EstimatedMixProp) = rownames(RelProportion)
  EstimatedMixProp = apply(EstimatedMixProp[,1:b],2,mean)
  
  EstimatedMixProp = matrix(EstimatedMixProp,b,1,dimnames = list(classes,"Pop	Est.Pi"))
  
  # Write mixing proportions into a file:
  
  write.table(EstimatedMixProp,"NetworkMethod/MixProp.txt",quote = F)
  
  return(list("ProbofOrigin"=RelProportion,"MixtureProp"=EstimatedMixProp,
              "OutgroupMembers"=Outsiders,"NmbOfNeighbors"=Freq))
  
}


