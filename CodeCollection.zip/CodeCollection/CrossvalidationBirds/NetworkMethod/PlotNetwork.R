
# 12.08.2019

# Plot a network from a network estimated with WTA among 50 simulated data sets

# Remember, that the outgroup was removed from the analysis

library(igraph)

AWTA = read.table("SummarypsiLambda.txt",header=T,row.names = 1,check.names = F) # Adjacency matrix of the WTA method
Baseline = read.table("C:/Users/kuismima/Desktop/HighSparrow/Aineisto/AllYears/All_years_1998-2012/2012/Baseline/alladults2012_basepop_ref.txt",stringsAsFactors=F)

rownames(Baseline) = Baseline$V1

Baseline = Baseline[Baseline$V2 != 77,]

# Order individuals as they appear in the baseline file:

BaselineBirds = colnames(AWTA[,1:407])
MixtureBirds = colnames(AWTA[408:ncol(AWTA)]) # There are 100 mixture birds

Baseline = Baseline[BaselineBirds,]

all.equal(Baseline$V1,BaselineBirds) # Just checking that birds are in order

###################################################

AWTA = as.matrix(AWTA)

Net = graph.adjacency(AWTA,mode="undirected",diag=F,add.colnames = T)

V(Net)$name = colnames(AWTA)

Baselinecolors = rainbow(length(table(Baseline$V2)))

Birdcolors = Baseline$V2

table(Birdcolors)

# Color order has to be re-thinke:

plot(1:9,col=Baselinecolors,pch=16,cex=2)

Birdcolors[Birdcolors == "20"] = Baselinecolors[5]
Birdcolors[Birdcolors == "22"] = Baselinecolors[8]
Birdcolors[Birdcolors == "23"] = Baselinecolors[7]
Birdcolors[Birdcolors == "24"] = Baselinecolors[6]
Birdcolors[Birdcolors == "26"] = Baselinecolors[4]
Birdcolors[Birdcolors == "27"] = Baselinecolors[3]
Birdcolors[Birdcolors == "28"] = Baselinecolors[2]
Birdcolors[Birdcolors == "38"] = Baselinecolors[1]

Birdcolors = c(Birdcolors,rep("white",length(MixtureBirds)))    

VSize = c(rep(4,length(BaselineBirds)),rep(2,length(MixtureBirds)))

wc = cluster_walktrap(Net)

wc$membership[1:length(BaselineBirds)] = Baseline$V2

coords = layout_with_fr(Net)

#plot(Net,vertex.color=Birdcolors,vertex.label=colnames(AWTA),
#     vertex.label.cex=0.5,vertex.size=VSize,edge.color="black",layout=coords)

plot(Net,vertex.color=Birdcolors,vertex.label.cex=0.5,vertex.size=VSize,edge.color="black",vertex.label=NA)

################################################################

# Remove individuals with zero degree:

RmThese = which(colSums(AWTA) == 0)

ACleaned = AWTA[-RmThese,-RmThese]
BaselineCleaned = Baseline[-RmThese,]

NetCleaned = graph.adjacency(ACleaned,mode="undirected",diag=F,add.colnames = T)

V(NetCleaned)$name = colnames(ACleaned)

Birdcolors = BaselineCleaned$V2

table(Birdcolors)

Birdcolors[Birdcolors == "20"] = Baselinecolors[5]
Birdcolors[Birdcolors == "22"] = Baselinecolors[8]
Birdcolors[Birdcolors == "23"] = Baselinecolors[7]
Birdcolors[Birdcolors == "24"] = Baselinecolors[6]
Birdcolors[Birdcolors == "26"] = Baselinecolors[4]
Birdcolors[Birdcolors == "27"] = Baselinecolors[3]
Birdcolors[Birdcolors == "28"] = Baselinecolors[2]
Birdcolors[Birdcolors == "38"] = Baselinecolors[1]

VSize = c(rep(6,length(Birdcolors)),rep(4,length(MixtureBirds)))

Birdcolors = c(Birdcolors,rep("white",length(MixtureBirds)))    

wc = cluster_walktrap(NetCleaned)

wc$membership[1:nrow(BaselineCleaned)] = BaselineCleaned$V2

plot(NetCleaned,vertex.color=Birdcolors,vertex.label=colnames(ACleaned),
     vertex.label.cex=0.5,vertex.size=VSize,edge.color="black",vertex.label.color="black")

pdf("WTANetworkEstimate.pdf", paper="a4r")

plot(NetCleaned,vertex.color=Birdcolors,vertex.label=colnames(ACleaned),
     vertex.label.cex=0.5,vertex.size=VSize,edge.color="black",vertex.label.color="black")

dev.off()


# Make a map:

library(raster)

Norway = getData('GADM', country='NOR', level=1)

# Remember, simulated data:

Mixture = read.table("C:/Users/kuismima/Desktop/HighSparrow/Aineisto/AllYears/All_years_1998-2012/2012/Baseline/alladults2012_basepop_ref.txt",stringsAsFactors=F)

rownames(Mixture) = Mixture$V1

Mixture = Mixture[Mixture$V1 %in% MixtureBirds,] 

Mixture = Mixture[match(MixtureBirds, Mixture$V1),]

all.equal(MixtureBirds,Mixture$V1)

LonCoords = c(BaselineCleaned$V2,Mixture$V2)
LatCoords = LonCoords

Birdcolors2 = LonCoords
IslandSizes = LonCoords

table(LonCoords)

IslandSizes[IslandSizes == 20] = sum(Baseline$V2 == 20) 
IslandSizes[IslandSizes == 22] = sum(Baseline$V2 == 22) 
IslandSizes[IslandSizes == 23] = sum(Baseline$V2 == 23) 
IslandSizes[IslandSizes == 24] = sum(Baseline$V2 == 24) 
IslandSizes[IslandSizes == 26] = sum(Baseline$V2 == 26) 
IslandSizes[IslandSizes == 27] = sum(Baseline$V2 == 27) 
IslandSizes[IslandSizes == 28] = sum(Baseline$V2 == 28) 
IslandSizes[IslandSizes == 38] = sum(Baseline$V2 == 38) 

LonCoords[LonCoords == 20] = 12.646
LonCoords[LonCoords == 22] = 12.482
LonCoords[LonCoords == 23] = 12.153
LonCoords[LonCoords == 24] = 12.242
LonCoords[LonCoords == 26] = 13.034
LonCoords[LonCoords == 27] = 12.818
LonCoords[LonCoords == 28] = 12.948
LonCoords[LonCoords == 38] = 13.035
  
LatCoords[LatCoords == 20] = 66.579
LatCoords[LatCoords == 22] = 66.763
LatCoords[LatCoords == 23] = 66.539
LatCoords[LatCoords == 24] = 66.588
LatCoords[LatCoords == 26] = 66.62
LatCoords[LatCoords == 27] = 66.539
LatCoords[LatCoords == 28] = 66.487
LatCoords[LatCoords == 38] = 66.403

Birdcolors2[Birdcolors2 == 20] = Baselinecolors[5]
Birdcolors2[Birdcolors2 == 22] = Baselinecolors[8]
Birdcolors2[Birdcolors2 == 23] = Baselinecolors[7]
Birdcolors2[Birdcolors2 == 24] = Baselinecolors[6]
Birdcolors2[Birdcolors2 == 26] = Baselinecolors[4]
Birdcolors2[Birdcolors2 == 27] = Baselinecolors[3]
Birdcolors2[Birdcolors2 == 28] = Baselinecolors[2]
Birdcolors2[Birdcolors2 == 38] = Baselinecolors[1]

IslandCoordinates = data.frame("name"=colnames(ACleaned),"lon"= LonCoords, "lat"= LatCoords)

lo = as.matrix(IslandCoordinates[,2:3])
plot(Norway,ylim=c(66.33,66.764),xlim=c(12.15,13.036),col="gray80",border="gray40",axes=T,las=1)
plot(NetCleaned, layout=lo, add = TRUE, rescale = F, vertex.color=Birdcolors2, vertex.size=IslandSizes/25, 
     edge.color="black", vertex.label=NA)

