WTAInference=function(MBapprox,ReferenceData,SampleNames,SampleSizeBaselinePop,NmbOfParents=1){
  
  # By default, the condition is "associate the mixture individual to baseline population where
  # the first neighbor is found"
  
  p = ncol(MBapprox[,,1]) # Total number of samples
  
  lambdalength = dim(MBapprox)[3]
  
  SampleSizeMixPop = p - SampleSizeBaselinePop
  
  MixInd = (SampleSizeBaselinePop + 1):p # Assuming, that data is ("Baseline columns","Mixture columns")
  BaselineInd = 1:SampleSizeBaselinePop
  
  ############################################################
  
  lambdalength = dim(MBapprox)[3]
  
  AllMixConnected = matrix(0,nrow=SampleSizeMixPop,ncol=lambdalength)
  
  lambda = NULL
  
  for(i in 1:lambdalength){
    lambda[i] = paste("lambda",i,sep="") 
  }
  
  colnames(AllMixConnected) = lambda
  rownames(AllMixConnected) = SampleNames[MixInd]
  
  ############################################################
  
  
  AllpsiLambda = array(0,c(p,p,lambdalength))
  
  for(index in 1:lambdalength){ # Larger graph index means denser graph
    
    NewMBapprox2 = MBapprox[,,index]
    
    colnames(NewMBapprox2) = SampleNames
    rownames(NewMBapprox2) = SampleNames
    
    NewMBapprox2 = as.matrix(NewMBapprox2)
    
    NewMBapprox2 = NewMBapprox2*t(NewMBapprox2)
    
    psiLambda = ifelse(NewMBapprox2 != 0 , 1, 0)
    
    ###############################################################################

    # Count the number of neighbors with a lambda value "lambda_index". Usually less neighbors
    # with smaller lambda = smaller index
    
    AllMixConnected[,index] = colSums(psiLambda[BaselineInd,MixInd])
    
    AllpsiLambda[,,index] = psiLambda
    
  }
  
  dimnames(AllpsiLambda)[[1]] = rownames(psiLambda)
  dimnames(AllpsiLambda)[[2]] = colnames(psiLambda)
  
  #which(rowSums(AllMixConnected) == 0) # No parents
  
  ############################################################
  
  # Find the first adjacency matrix (psiLambda) which fulfils a condition: 
  
  FirstpsiLambda = data.frame(sampleID=rownames(AllMixConnected),index=0)
  
  rownames(FirstpsiLambda) = rownames(AllMixConnected)
  
  for(i in 1:nrow(AllMixConnected)){
    
    FirstpsiLambda[i,2] =  which(AllMixConnected[i,] >= NmbOfParents)[1] # Try different conditions
    
  }
  
  # Are there individuals with no baseline population?
  
  #sum(is.na(FirstpsiLambda[,2]))
  
  NoFounds = which(is.na(FirstpsiLambda[,2]))
  
  ############################################################
  
  # Collect neighbours to a summary matrix:
  
  SummarypsiLambda = matrix(0,p,p)
  
  rownames(SummarypsiLambda) = dimnames(AllpsiLambda)[[1]]
  colnames(SummarypsiLambda) = dimnames(AllpsiLambda)[[2]]
  
  FirstpsiLambda[NoFounds,2] = 1
  
  for(i in 1:nrow(AllMixConnected)){
    
    # Neighbourhood of Baseline:
    
    SummarypsiLambda[,as.character(FirstpsiLambda[i,1])] = 
      AllpsiLambda[,as.character(FirstpsiLambda[i,1]),FirstpsiLambda[i,2]]
    
    # Neighbourhood of Mixture:
    
    SummarypsiLambda[as.character(FirstpsiLambda[i,1]),] = 
      AllpsiLambda[as.character(FirstpsiLambda[i,1]),,FirstpsiLambda[i,2]]
    
  }
  
  write.table(SummarypsiLambda,file="NetworkMethod/SummarypsiLambda.txt",quote=F)
  
  ########################################################################
  ########################################################################
  
  b = length(unique(ReferenceData$repunit)) # nmb of classes
    
  Freq = rowsum(SummarypsiLambda[BaselineInd,MixInd],ReferenceData$repunit)
  
  dimnames(Freq)[[2]] = colnames(psiLambda)[MixInd]
  
  # Populations are in order: 
  
  #sort(unique(ReferenceData$repunit))
  
  classes = sort(unique(ReferenceData$repunit))
  
  # How many times the neighborhood was present over different penalizations?
  
  RelProportion = apply(Freq,2,function(x) x/sum(x)) # Standardized weighted frequencies
  
  RelProportion = t(RelProportion)
  
  # Write probability of the origin results into a table:
  
  write.table(RelProportion,"NetworkMethod/RelProbOfOriginWTA.txt",quote = F)
  
  # Determine also the mixing proportions:
  
  EstimatedMixProp = apply(RelProportion[,1:b],2,as.numeric)
  rownames(EstimatedMixProp) = rownames(RelProportion)
  EstimatedMixProp = apply(EstimatedMixProp[,1:b],2,mean)
  
  EstimatedMixProp = matrix(EstimatedMixProp,b,1,dimnames = list(classes,"Pop	Est.Pi"))
  
  # Write mixing proportions into a file:
  
  write.table(EstimatedMixProp,"NetworkMethod/MixPropWTA.txt",quote = F)
  
  return(list("ProbofOrigin"=RelProportion,"MixtureProp"=EstimatedMixProp))
  
}