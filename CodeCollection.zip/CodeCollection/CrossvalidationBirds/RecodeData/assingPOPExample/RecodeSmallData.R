
# 30.11.2018

# Make a small data set to play with assingPOP

library(data.table)
library(gtools)

# Use SNP data from Norwegian birds:

Classes = rep("character",366296) # The number of columns in the data file

year = 2012

# Files "BirdFile", "repunitfile" and "MAPFile" define file paths. Change them to your own!

BirdFile = paste("C:/Users/Desktop/HighSparrow/AllYears/All_years_1998-2012/",year,"/Baseline/",
                 "Basepop",year,"_200K.ped",sep="")

BirdRef = fread(BirdFile, colClasses = Classes)
dim(BirdRef)

repunitfile = paste("C:/Users/Desktop/HighSparrow/AllYears/All_years_1998-2012/",year,"/Baseline/",
                    "alladults",year,"_basepop_ref.txt",sep="")

repunit = read.table(repunitfile,header=F,colClasses = c("character","character"))

all.equal(BirdRef$V2,repunit$V1) # Not in the same order...

BirdRef = BirdRef[match(repunit$V1,BirdRef$V2),]

all.equal(BirdRef$V2,repunit$V1) # Now samples are in order

MAPFile = paste("C:/Users/Desktop/HighSparrow/AllYears/All_years_1998-2012/",year,"/Baseline/",
                "Basepop",year,"_200K.map",sep="")

MAP = read.table(MAPFile,header=F,colClasses = c("numeric","character","numeric","numeric"))

# Rename SNPs

SNPNames = MAP$V2
length(SNPNames)
rm(MAP)

str(BirdRef[,1:7])

# Work with a smaller example data:

str(BirdRef[,1:7])  
K = nrow(BirdRef)

BirdAlleles = BirdRef[,-(1:6)]
BirdAlleles = as.matrix(BirdAlleles) # This makes replacing values much faster
rm(BirdRef)

# Choose, say, 1000 SNPs:

N = 1000

Samplematrix = matrix(1:ncol(BirdAlleles),nrow=ncol(BirdAlleles)/2,2,byrow=T)

# Systematic sampling:

k = nrow(Samplematrix)/N # Skip value
r = runif(1,0,k) # Start value
ind = seq(r, r + k*(N-1), k)
ind = ceiling(ind)

Sampleind = Samplematrix[ind,]

BirdAlleles = BirdAlleles[,sort(as.vector(Sampleind))]
SNPNames = SNPNames[ind]

BirdAlleles[BirdAlleles == "0"] = "-"

IndOdd = seq(1,ncol(BirdAlleles),by=2)

SNPDataMatrix = matrix(NA,length(SNPNames),K)
rm(K)

k = 1
for(i in IndOdd){
  
  loci.1 = BirdAlleles[,i]
  loci.2 = BirdAlleles[,i+1]
  SNPDataMatrix[k,] = paste(loci.1,loci.2,sep="")
  
  cat("\r",k)
  
  k = k + 1
  
}

SNPDataMatrix = cbind(SNPNames,SNPDataMatrix)

colnames(SNPDataMatrix) = c("SNP_ID",paste("Island",repunit$V2,"_",repunit$V1,sep=""))

SNPDataMatrix = rbind(colnames(SNPDataMatrix),SNPDataMatrix)

library(diveRsity)
data(SNPs)

# Don't use the same coding or naming. snp2genpop is little f****d up

dim(SNPDataMatrix)

#write.table(SNPDataMatrix,"Bird2012SNPsRecoded.txt",quote=F,row.names = F)

snp2gen(infile = SNPDataMatrix, prefix_length = 8) # First row of the file has to specify population names!!!
