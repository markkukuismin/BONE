
# 30.11.2018

library(assignPOP)
library(diveRsity)
library(rubias)

#####################################

# A small data example

# There must not be "pop" or "POP" in sample names when the data is read with assignPOP "read.Genepop" function!

DataAssingPOP = read.Genepop("snp2gen_converted.gen", pop.names=c("38","28","27","26","20","24","23","22","77"),
                             haploid = FALSE)

# Use RUBIAS to simulate mixture samples from baseline:

# I have prepared a small bird ref-file to use with RUBIAS. This is the same set of SNPs! There are 1000 SNPs

classes = c(rep("character",4),rep("integer",2000))
SmallBirdRef = read.table("SmallBirdRefRUBIAS.txt",stringsAsFactors = F,colClasses = classes,header=T)
rm(classes)

table(SmallBirdRef$repunit)

rhos = as.vector(gtools::rdirichlet(1, table(SmallBirdRef$repunit)))
N = 100 # Nmb of mixture individuals

cross_val = mixture_draw(D = SmallBirdRef, rhos = rhos, N = N, min_remaining = .005) # Simulate data

MixtureDataRUBIAS = cross_val$mixture
RefDataRUBIAS = cross_val$reference

###########################################################

# Divide genePOP data into a mixture and baseline sets:

DataMatrix = DataAssingPOP$DataMatrix
dim(DataMatrix)

DataMatrix[1:3,1:5]
table(DataMatrix[,401]) # The last column is the population name

AssignPOPSamples = DataAssingPOP$SampleID
AssignPOPSamples = substring(AssignPOPSamples,10) # Remove useless characters

rownames(DataMatrix) = AssignPOPSamples

RefDataAssignPOP = DataMatrix[RefDataRUBIAS$indiv,] # Substract reference individuals

MixtureDataAssignPOP = DataMatrix[MixtureDataRUBIAS$indiv,] # Substract mixture individuals
MixtureDataAssignPOP[,ncol(MixtureDataAssignPOP)] = NA # Unknown origin


names(DataAssingPOP)

LocusName = DataAssingPOP$LocusName

# Finally one can generate datafiles for genePOP:

RefDataAssignPOP = list("DataMatrix"=RefDataAssignPOP,"SampleID"=rownames(RefDataAssignPOP),"LocusName" = LocusName)
MixtureDataAssignPOP = list("DataMatrix"=MixtureDataAssignPOP,"SampleID"=rownames(MixtureDataAssignPOP),
                            "LocusName" = LocusName)

rm(DataAssingPOP)

####################################################

# Now we can analyse the data with assignPOP. The default classifier is the support vector machine:

trash <- assign.X(x1=RefDataAssignPOP,x2=MixtureDataAssignPOP,dir="AssignPOPResults/",mplot=T, model="svm") 
rm(trash)

# RUBIAS:

mcmc = infer_mixture(reference=RefDataRUBIAS,mixture=MixtureDataRUBIAS,gen_start_col=5,method="MCMC",reps=1000)

MixingProp = mcmc$mixing_proportions # These are the mixing proportions in 3 regions, 6 populations in each
IndivProps = mcmc$indiv_posteriors 

# Reorder individuals in the probability of the origin table in the same order as they appear in the 
# original mixture data file:

NewOrder = matrix(0,length(rhos),nrow(MixtureDataRUBIAS))

for(i in 1:nrow(MixtureDataRUBIAS)){
  
  NewOrder[,i] = which(IndivProps$indiv == MixtureDataRUBIAS$indiv[i])
  
}

NewOrder = as.vector(NewOrder)

IndivProps = IndivProps[NewOrder,] # Finally, order data according to how individuals appear in the mixture data file

###############################################################
###############################################################

MixtureSmaller = MixtureDataRUBIAS[,2:4] # Just to make working with the table easier

MixtureTruth = data.frame(repunit=IndivProps$repunit,indiv=IndivProps$indiv,PofZ=rep(0,nrow(IndivProps)),
                          stringsAsFactors = F)

MixtureSmaller = as.data.frame(MixtureSmaller) # Tables aren't exactly the same but now they are

Ind = matrix(1:nrow(MixtureTruth),nrow=length(rhos)) # Indicator variable to find rows of one individuals

# Finally, set "PopZ" to the "true" value, in other words to 1:

for(j in 1:ncol(Ind)){
  
  i = which(MixtureTruth$repunit[Ind[,j]] == MixtureSmaller$repunit[j])
  MixtureTruth[Ind[i,j],3] = 1 
  
}


# Plot Barplots:

MRUBIAS = matrix(IndivProps$PofZ,nrow=length(rhos),ncol=nrow(MixtureDataRUBIAS))

MAssignPOP = read.table("AssignPOPResults/AssignmentResult.txt",header=T,stringsAsFactors = F,check.names = F)
MAssignPOP = t(MAssignPOP[,3:ncol(MAssignPOP)])
MAssignPOP = MAssignPOP[IndivProps$repunit[1:9],] # Order rows (populations) in the same order they are in MRUBIAS file

MTrue = matrix(MixtureTruth$PofZ,nrow=length(rhos),ncol=nrow(MixtureDataRUBIAS))

par(mfrow=c(3,1))
barplot(MRUBIAS, col = rainbow(length(rhos)), space = 0,
        xlab = NULL, ylab = "Prob. of origin",
        main="RUBIAS",yaxt="n")
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025)

barplot(MAssignPOP, col = rainbow(length(rhos)), space = 0,
        xlab = NULL, ylab = "Prob. of origin",
        main="AssignPOP",yaxt="n")
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025)
abline(h=0.5, lty=2)

# True populations are in order (from left to right):

unique(MixtureDataRUBIAS$repunit)
table(MixtureDataRUBIAS$repunit)

barplot(MTrue, col = rainbow(length(rhos)), space = 0,
        xlab = "Individuals", ylab = "Prob. of origin",
        main="Truth",yaxt="n")
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025)

###########################################################################

# Mixtureproportions of the assignPOP can be estimated by the row means of the MassignPOP:

MAssignPOP = read.table("AssignPOPResults/AssignmentResult.txt",header=T,stringsAsFactors = F,check.names = F)
MAssignPOP = t(MAssignPOP[,3:ncol(MAssignPOP)])

rowMeans(MAssignPOP[names(table(SmallBirdRef$repunit)),])
rhos
table(SmallBirdRef$repunit)/sum(table(SmallBirdRef$repunit))
