
"snp2gen_converted.gen" is a genepop format SNP data of year 2012 birds. Check the directory "assingPOPExample" for a small illustrative example.