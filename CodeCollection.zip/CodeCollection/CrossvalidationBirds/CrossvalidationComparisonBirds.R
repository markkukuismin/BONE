
# 18.06.2019

library(glmnet)
library(rubias)
library(gtools)
library(igraph)
library(data.table)
library(assignPOP)
library(radmixture)

# Use SNP data from Norwegian birds:

Classes = rep("character",366296) # The number of columns in the data file

year = 2012

# This is the file path of the .ped file. Change it!

BirdFile = paste("C:/Users/HighSparrow/AllYears/All_years_1998-2012/",year,"/Baseline/",
                 "Basepop",year,"_200K.ped",sep="")

SmallBirdRef = fread(BirdFile, colClasses = Classes)

SmallBirdRefADMIXTURE = SmallBirdRef

SmallBirdRef = SmallBirdRef[,-c(1,3,4,5,6)]

str(SmallBirdRef[,1:3])

# This is the file path of the .ref file. Change it!

repunitfile = paste("C:/Users/Desktop/HighSparrow/AllYears/All_years_1998-2012/",year,"/Baseline/",
                    "alladults",year,"_basepop_ref.txt",sep="")

repunit = read.table(repunitfile,header=F,colClasses = c("character","character"))

str(repunit)

dim(SmallBirdRef)

all.equal(SmallBirdRef$V2,repunit$V1) # Not in the same order...

SmallBirdRef = SmallBirdRef[match(repunit$V1,SmallBirdRef$V2),]
SmallBirdRefADMIXTURE = SmallBirdRefADMIXTURE[match(repunit$V1,SmallBirdRefADMIXTURE$V2),]

all.equal(SmallBirdRefADMIXTURE$V2,repunit$V1) # Now samples are in order

SampleSizeBaseline = nrow(SmallBirdRef)

# Modify dataset for rubias:

SmallBirdRef = SmallBirdRef[,-1] # Makes the conversion to numeric variables easier/faster (*)
SmallBirdRef = as.matrix(SmallBirdRef) # This makes replacing values much faster

SmallBirdRefADMIXTURE = as.matrix(SmallBirdRefADMIXTURE)

# Here I follow the coding of Anderson: https://github.com/eriqande/gsi_sim (*)

SmallBirdRef[SmallBirdRef == "0"] <- NA # Missing values
SmallBirdRef[SmallBirdRef == "A"] <- 1
SmallBirdRef[SmallBirdRef == "C"] <- 2
SmallBirdRef[SmallBirdRef == "G"] <- 3
SmallBirdRef[SmallBirdRef == "T"] <- 4

SmallBirdRefADMIXTURE[SmallBirdRefADMIXTURE == "0"] <- 0 # Missing values
SmallBirdRefADMIXTURE[SmallBirdRefADMIXTURE == "A"] <- 1
SmallBirdRefADMIXTURE[SmallBirdRefADMIXTURE == "C"] <- 2
SmallBirdRefADMIXTURE[SmallBirdRefADMIXTURE == "G"] <- 3
SmallBirdRefADMIXTURE[SmallBirdRefADMIXTURE == "T"] <- 4

SmallBirdRef = as.data.frame(SmallBirdRef,stringsAsFactors=F)

SmallBirdRefADMIXTURE = as.data.frame(SmallBirdRefADMIXTURE,stringsAsFactors=F)

str(SmallBirdRef[ ,1:10])

str(SmallBirdRefADMIXTURE[ ,1:11])

# Use just small proportion of SNPs:

Samplematrix = matrix(1:ncol(SmallBirdRef),nrow=ncol(SmallBirdRef)/2,2,byrow=T)

n = 1000 # Say, use this many SNPs: nmb of loci = 2*n 

# Systematic sampling:

k = nrow(Samplematrix)/n # Skip value
r = runif(1,0,k) # Start value
ind = seq(r, r + k*(n-1), k)
ind = ceiling(ind)

Sampleind = Samplematrix[ind,]

SmallBirdRef = SmallBirdRef[ ,sort(as.vector(Sampleind))]

PedColumns = SmallBirdRefADMIXTURE[ ,1:6]

SmallBirdRefADMIXTURE = SmallBirdRefADMIXTURE[ ,sort(as.vector(Sampleind)) + 6]

str(SmallBirdRef[ ,1:10])

str(SmallBirdRefADMIXTURE[ ,1:10])

SmallBirdRefADMIXTURE[] = lapply(SmallBirdRefADMIXTURE, function(x) as.integer(as.character(x)))

SmallBirdRefADMIXTURE = cbind(PedColumns,SmallBirdRefADMIXTURE)

SmallBirdRef[] = lapply(SmallBirdRef, function(x) as.integer(as.character(x)))

str(SmallBirdRef[,1:10])

str(SmallBirdRefADMIXTURE[,1:16])

SmallBirdRef = cbind(indiv = repunit$V1, SmallBirdRef)
SmallBirdRef = cbind(collection = paste(repunit$V2,".1",sep=""),SmallBirdRef)
SmallBirdRef = cbind(repunit = repunit$V2,SmallBirdRef)
SmallBirdRef = cbind(sample_type = rep("reference",times=SampleSizeBaseline),SmallBirdRef)

str(SmallBirdRef[,1:20])

SmallBirdRef$sample_type = as.character(SmallBirdRef$sample_type)
SmallBirdRef$repunit = as.character(SmallBirdRef$repunit)
SmallBirdRef$collection = as.character(SmallBirdRef$collection)
SmallBirdRef$indiv = as.character(SmallBirdRef$indiv)

str(SmallBirdRef[,1:20])

rm(list=setdiff(ls(), c("SmallBirdRef","SmallBirdRefADMIXTURE","year","Sampleind","n")))

# Remove individuals from repunit 77: This is a group full of dispersers which will distort classifications:

InsideDispersers = which(SmallBirdRef$repunit == "77")

SmallBirdRef = SmallBirdRef[-InsideDispersers,]
SmallBirdRefADMIXTURE = SmallBirdRefADMIXTURE[-InsideDispersers,]

write.table(SmallBirdRef,"SmallBirdRef.txt",row.names=F,quote=F) # Write the data on the disk
write.table(SmallBirdRefADMIXTURE,"SmallBirdRefADMIXTURE.txt",row.names=F,quote=F) # Write the data on the disk

############################################################
############################################################

# Load functions needed for the network inference method:

source("NetworkMethod/impute.R")
source("NetworkMethod/LASSOSolPath.R")
source("NetworkMethod/SolPathInference.R")
source("NetworkMethod/WTAInference.R")

source("radmixtureEstimator.R")

MSE = function(x,y){
  
  mean((x-y)^2)
  
}

rhos = as.vector(gtools::rdirichlet(1, table(SmallBirdRef$repunit)))

# The expected value of "rhos" is

table(SmallBirdRef$repunit)/sum(table(SmallBirdRef$repunit))

N = 100 # Nmb of mixture individuals

M = 50 # Number of simulation rounds

Results = matrix(0,nrow=M,ncol=12)
colnames(Results) = c("Prob.origin.ADMIXTURE","Mix.Prop.ADMIXTURE",
                      "Prob.origin.RUBIAS.MCMC","Mix.Prop.RUBIAS.MCMC",
                      "Prob.origin.Net.WTA","Mix.Prop.Net.WTA",
                      "Prob.origin.Net.SolPath","Mix.Prop.Net.SolPath",
                      "Prob.origin.AssignPOP.SVM","Mix.Prop.AssignPOP.SVM",
                      "Prob.origin.AssignPOP.NB","Mix.Prop.AssignPOP.NB")

ModifiedSNPs = matrix(0,nrow=M,ncol=3)
colnames(ModifiedSNPs) = c("Removed","Mono","Imputed")

#######################################################

# Read in assignPOP data. This is really tiresome but has to be done just once:

DataAssingPOP = read.Genepop("snp2gen_converted.gen", pop.names=c("38","28","27","26","20","24","23","22","77"),
                             haploid = FALSE)

DataMatrix = DataAssingPOP$DataMatrix
dim(DataMatrix)
str(DataMatrix[,1:5]) # Just to check that same SNPs are selecte from the matrix

AssignPOPSamples = DataAssingPOP$SampleID
AssignPOPSamples = substring(AssignPOPSamples,10) # Remove useless characters

rownames(DataMatrix) = AssignPOPSamples

LocusName = DataAssingPOP$LocusName
length(LocusName) # This mismatches with the original SNP length! Obviously read.Genepop has dropped one(...) SNP out (')

# For the reason mentioned above ('), choose SNPs according to their name:

MAPFile = paste("C:/Users/Desktop/HighSparrow/AllYears/All_years_1998-2012/",year,"/Baseline/",
                "Basepop",year,"_200K.map",sep="")

MAP = read.table(MAPFile,header=F,colClasses = c("numeric","character","numeric","numeric"))

SampleSNPs = MAP$V2
length(SampleSNPs)
rm(MAP)

SampleSNPs = SampleSNPs[Sampleind[,2]/2]

SampleSNPsInd = rep(0,n)

for(i in 1:n){
  
  SampleSNPsInd[i] = which(LocusName == SampleSNPs[i])
  
}

all.equal(LocusName[SampleSNPsInd],SampleSNPs)

SampleSNPsInd = 2*SampleSNPsInd

SampleSNPsInd = cbind(SampleSNPsInd-1,SampleSNPsInd)

# Pick the same SNPs as above:

DataMatrix = DataMatrix[,c(as.vector(sort(SampleSNPsInd)),ncol(DataMatrix))] # The last column contains the stock info

dim(DataMatrix)

# Remove the disperser group:

table(DataMatrix$popNames_vector)

InsideDispersers = which(DataMatrix$popNames_vector == "77")

DataMatrix = DataMatrix[-InsideDispersers,]

dim(DataMatrix)

DataMatrix$popNames_vector = factor(DataMatrix$popNames_vector)

table(DataMatrix$popNames_vector)

#######################################################

FinalTest = colnames(DataMatrix[,seq(1,ncol(DataMatrix)-1,by=2)])
FinalTest = substring(FinalTest,1,nchar(FinalTest)-3)

all.equal(FinalTest,SampleSNPs) # Good if TRUE!

rm(DataAssingPOP)

#######################################################

save.image()

for(k in 1:M){
  
  # Simulate data with RUBIAS:
  
  cross_val = mixture_draw(D = SmallBirdRef, rhos = rhos, N = N, min_remaining = .005) # Simulate data
  
  MixtureData = cross_val$mixture
  ReferenceData = cross_val$reference # There are "number of original baseline samples" - N samples in the reference file,
  # about, see "min_remaining"
  
  ########
  # RUBIAS
  ########
  
  #############################
  # Analyse the simulated data:
  #############################
  
  mcmc = infer_mixture(reference=ReferenceData,mixture=MixtureData,gen_start_col=5,method = "MCMC",reps=1000)
  #pb = infer_mixture(reference=ReferenceData,mixture=MixtureData,gen_start_col=5,method = "PB",reps=1000,pb_iter = 100)
  
  # RUBIAS with bootstrapping only corrects the mixture proportions...
  
  ############################################################################
  
  MixingPropMCMC = mcmc$mixing_proportions # These are the mixing proportions
  IndivProbsMCMC = mcmc$indiv_posteriors # These are the posterior estimates of the probability of the origin
  
  ############################################################################
  
  # Reorder individuals in the probability of the origin table in the same order as they appear in the 
  # original mixture data file:
  
  NewOrder = matrix(0,length(rhos),nrow(MixtureData))
  
  for(i in 1:nrow(MixtureData)){
    
    NewOrder[,i] = which(IndivProbsMCMC$indiv == MixtureData$indiv[i])
    
  }
  
  NewOrder = as.vector(NewOrder)
  
  IndivProbsMCMC = IndivProbsMCMC[NewOrder,] # Finally, order data according to how individuals appear in 
                                             # the mixture data file
  
  MixtureSmaller = MixtureData[,2:4] # Just to make working with the table easier
  
  MixtureTruth = data.frame(repunit=IndivProbsMCMC$repunit,indiv=IndivProbsMCMC$indiv,PofZ=rep(0,nrow(IndivProbsMCMC)),
                            stringsAsFactors = F)
  
  MixtureSmaller = as.data.frame(MixtureSmaller) # Tables aren't exactly the same but now they are
  
  Ind = matrix(1:nrow(MixtureTruth),nrow=length(rhos)) # Indicator variable to find rows of one individuals
  
  # Finally, set "PopZ" to the "true" value, in other words to 1:
  
  for(j in 1:ncol(Ind)){
    
    i = which(MixtureTruth$repunit[Ind[,j]] == MixtureSmaller$repunit[j])
    MixtureTruth[Ind[i,j],3] = 1 
    
  }
  
  ##########################################################################
  ##########################################################################
  
  ############
  # AssignPOP 
  ############
  
  RefDataAssignPOP = DataMatrix[ReferenceData$indiv,] # Substract reference individuals
  
  MixtureDataAssignPOP = DataMatrix[MixtureData$indiv,] # Substract mixture individuals
  MixtureDataAssignPOP[,ncol(MixtureDataAssignPOP)] = NA # Unknown origin
  
  # Finally one can generate datafiles for genePOP:
  
  RefDataAssignPOP = list("DataMatrix"=RefDataAssignPOP,"SampleID"=rownames(RefDataAssignPOP),"LocusName"=SampleSNPs)
  MixtureDataAssignPOP = list("DataMatrix"=MixtureDataAssignPOP,"SampleID"=rownames(MixtureDataAssignPOP),
                              "LocusName"=SampleSNPs)
  
  ####################################################
  
  # Now we can analyse the data with assignPOP. The default classifier is the support vector machine:
  
  trashSVM <- assign.X(x1=RefDataAssignPOP, x2=MixtureDataAssignPOP, dir="AssignPOPResultsSVM/", mplot=T, model="svm") 
  rm(trashSVM)
  
  trashNB <- assign.X(x1=RefDataAssignPOP, x2=MixtureDataAssignPOP, dir="AssignPOPResultsNB/", mplot=T, model="naiveBayes") 
  rm(trashNB)
  
  ####################################################
  
  # AssignPOP results are in an external file:
  
  MAssignPOPSVM = read.table("AssignPOPResultsSVM/AssignmentResult.txt",header=T,stringsAsFactors = F,check.names = F)
  rownames(MAssignPOPSVM) = MAssignPOPSVM$Ind.ID
  MAssignPOPSVM = t(MAssignPOPSVM[,3:ncol(MAssignPOPSVM)])
  
  MixPropAssignPOPSVM = rowMeans(MAssignPOPSVM[names(table(SmallBirdRef$repunit)),]) # Mixture proportions
  
  MAssignPOPSVM = MAssignPOPSVM[IndivProbsMCMC$repunit[1:length(rhos)],] # Order rows (populations) in the same order they are 
                                                              # in RUBIAS files
  
  ##########
  
  MAssignPOPNB = read.table("AssignPOPResultsNB/AssignmentResult.txt",header=T,stringsAsFactors = F,check.names = F)
  rownames(MAssignPOPNB) = MAssignPOPNB$Ind.ID
  MAssignPOPNB = t(MAssignPOPNB[,3:ncol(MAssignPOPNB)])
  
  MixPropAssignPOPNB = rowMeans(MAssignPOPNB[names(table(SmallBirdRef$repunit)),]) # Mixture proportions
  
  MAssignPOPNB = MAssignPOPNB[IndivProbsMCMC$repunit[1:length(rhos)],] # Order rows (populations) in the same order they are 
                                                            # in RUBIAS files
  
  ##########################################################################
  ##########################################################################
  
  ################
  # ADMIXTURE
  ################
  
  MADMIXTURE = radmixtureEstimator(MixtureData, ReferenceData, SmallBirdRefADMIXTURE)
  
  rownames(MADMIXTURE) = MixtureData$indiv
  
  MADMIXTURE =  MADMIXTURE[ ,sort(colnames(MADMIXTURE))]
  
  MixPropADMIXTURE = colMeans(MADMIXTURE[ ,names(table(SmallBirdRef$repunit))])
  
  ##########################################################################
  ##########################################################################
  
  ################
  # Network method
  ################
  
  MixtureY = impute(MixtureData) # Simple marker mode imputation
  ReferenceY = impute(ReferenceData)
  
  ModifiedSNPs[k,] = MixtureY$Removed + ReferenceY$Removed
  
  MixtureY = MixtureY$Y
  ReferenceY = ReferenceY$Y
  
  # Choose only same set of markers:
  setdiff(rownames(MixtureY),rownames(ReferenceY))
  Markers = intersect(rownames(MixtureY),rownames(ReferenceY))
  
  MixtureY = MixtureY[Markers,]
  ReferenceY = ReferenceY[Markers,]
  
  SampleSizeBaselinePop = ncol(ReferenceY)
  
  Y = cbind(ReferenceY,MixtureY)
  
  rm(list=c("ReferenceY","MixtureY"))
  
  #####
  
  lambda = seq(0.4,0.02,length.out=40)
  
  NeighborhoodSolPath = LASSOSolPath(Y,lambda=lambda,SampleSizeBaselinePop=SampleSizeBaselinePop) 
  
  # Hox! Non-symmetric network!
  save(NeighborhoodSolPath,file="NetworkMethod/SolutionPathBasAndMixNonSymmetricMBapprox.RData")
  
  ################################
  
  # Winner takes it all approach:
  
  NetworkResultsWTA = WTAInference(MBapprox=NeighborhoodSolPath,ReferenceData=ReferenceData,SampleNames=colnames(Y),
                                    SampleSizeBaselinePop=SampleSizeBaselinePop,NmbOfParents=1) #(*)
  
  ExpendapleM = NetworkResultsWTA$ProbofOrigi
  ExpendapleM = as.vector(t(ExpendapleM))
  
  NetworkIndivPofzWTA = data.frame(indiv=rep(MixtureSmaller$indiv,each=length(rhos)),PofZ=ExpendapleM,
                                       repunit = sort(unique(ReferenceData$repunit)),stringsAsFactors = F)
  
  # Individuals are in this order because of the function "rowsums" used in the function above (*)
  
  # Individuals should be in the same order:
  
  if(!all.equal(IndivProbsMCMC$indiv,NetworkIndivPofzWTA$indiv)){
    stop("Error: Individuals are out of order!") 
  }
  
  # Still need to arrange them according to the population names:
  
  a = seq(0,nrow(IndivProbsMCMC)-length(rhos),by=length(rhos))
  a = rep(a,each=length(rhos))
  
  a = match(IndivProbsMCMC$repunit,NetworkIndivPofzWTA$repunit) + a
  
  NetworkIndivPofzWTA = NetworkIndivPofzWTA[a, ]
  
  if(!all.equal(IndivProbsMCMC$repunit,NetworkIndivPofzWTA$repunit)){
    stop("Error: Populations are not in comparabel order!")
  }
  
  ################################
  
  # Solution path approach:
  
  NetworkResultsSolpath = SolPathInference(MBapprox=NeighborhoodSolPath,ReferenceData=ReferenceData,
                                           SampleNames=colnames(Y),SampleSizeBaselinePop=SampleSizeBaselinePop) #(*)
  
  ExpendapleM = NetworkResultsSolpath$ProbofOrigin
  ExpendapleM = as.vector(t(ExpendapleM[,-ncol(ExpendapleM)]))
  
  NetworkIndivPofzSolPath = data.frame(indiv=rep(MixtureSmaller$indiv,each=length(rhos)),PofZ=ExpendapleM,
                                       repunit = sort(unique(ReferenceData$repunit)),stringsAsFactors = F)
  
  # Individuals are in this order because of the function "rowsum" used in the function above (*)
  
  # Individuals should be in the same order:
  
  if(!all.equal(IndivProbsMCMC$indiv,NetworkIndivPofzSolPath$indiv)){
    stop("Error: Individuals are out of order!") 
  }
  
  # Still need to arrange them according to the population names:
  
  NetworkIndivPofzSolPath = NetworkIndivPofzSolPath[a, ]
  
  if(!all.equal(IndivProbsMCMC$repunit,NetworkIndivPofzSolPath$repunit)){
    stop("Error: Populations are not in comparabel order!")
  }
  
  ##########################################################################
  ##########################################################################
  
  MixingPropRUBIASMCMC = by(IndivProbsMCMC$PofZ,IndivProbsMCMC$repunit,mean) # Not the right way but 
                                                                             # produces smaller MSE...
  
  Results[k,1] = MSE(as.vector(t(MADMIXTURE[ ,unique(MixtureTruth$repunit)])),MixtureTruth$PofZ) # Prob. of origin ADMIXTURE
                                                                                                 # supervised learning
  Results[k,2] = MSE(MixPropADMIXTURE,rhos) # Mixture proportions, ADMIXTURE supervised learning
  
  Results[k,3] = MSE(IndivProbsMCMC$PofZ,MixtureTruth$PofZ) # Prob. of origin RUBIAS (MCMC) (**)
  Results[k,4] = MSE(MixingPropRUBIASMCMC,rhos) # Mixture proportions RUBIAS (MCMC) (**)
  
  Results[k,5] = MSE(NetworkIndivPofzWTA$PofZ,MixtureTruth$PofZ) # Prob. of origin Network WTA
  Results[k,6] = MSE(NetworkResultsWTA$MixtureProp,rhos) # Mixture proportions, Network WTA
  
  Results[k,7] = MSE(NetworkIndivPofzSolPath$PofZ,MixtureTruth$PofZ) # Prob. of origin Network solution path
  Results[k,8] = MSE(NetworkResultsSolpath$MixtureProp,rhos) # Mixture proportions, Network solution path
  
  Results[k,9] = MSE(as.vector(MAssignPOPSVM),MixtureTruth$PofZ) # Prob. of origin assignPOP (SVM)
  Results[k,10] = MSE(MixPropAssignPOPSVM,rhos) # Mixture proportions, assignPOP (SVM)
  
  Results[k,11] = MSE(as.vector(MAssignPOPNB),MixtureTruth$PofZ) # Prob. of origin assignPOP (naive Bayes)
  Results[k,12] = MSE(MixPropAssignPOPNB,rhos) # Mixture proportions, assignPOP (naive Bayes)
  
}

# Plot barplots of the prob. of origin:

MRUBIASMCMC = matrix(IndivProbsMCMC$PofZ,nrow=length(rhos),ncol=nrow(MixtureData))

rownames(MRUBIASMCMC) = unique(IndivProbsMCMC$repunit)
colnames(MRUBIASMCMC) = unique(IndivProbsMCMC$indiv)

#Reorder columns and rows:

MADMIXTURE = MADMIXTURE[, rownames(MRUBIASMCMC) ]
MADMIXTURE = MADMIXTURE[colnames(MRUBIASMCMC), ]

############################

MNetworkWTA = matrix(NetworkIndivPofzWTA$PofZ,nrow=length(rhos),ncol=nrow(MixtureData))
MNetworkSolPath = matrix(NetworkIndivPofzSolPath$PofZ,nrow=length(rhos),ncol=nrow(MixtureData))

############################

MTrue = matrix(MixtureTruth$PofZ,nrow=length(rhos),ncol=nrow(MixtureData))

colnames(MAssignPOPNB) = NULL
colnames(MAssignPOPSVM) = NULL

rownames(MADMIXTURE) = NULL

colnames(MRUBIASMCMC) = NULL

####################################

# Bayes methods and Winner takes it all method:

par(oma=c(3,3,0,0),mar=c(3,3,2,2),mfrow=c(4,1))

barplot(MRUBIASMCMC, col = rainbow(length(rhos)), space = 0,
        xlab = NULL, ylab = NULL,
        main="RUBIAS (MCMC)",yaxt="n",cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)
#abline(h=0.5, lty=2)

barplot(MAssignPOPNB, col = rainbow(length(rhos)), space = 0,
        xlab = NULL, ylab = NULL,
        main="AssignPOP (naive Bayes)",yaxt="n",cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)
#abline(h=0.5, lty=2)

barplot(MNetworkWTA, col = rainbow(length(rhos)), space = 0,
        xlab = NULL, ylab = NULL,
        main="BONE (WTA)",yaxt="n",cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)
#abline(h=0.5, lty=2)

barplot(MTrue, col = rainbow(length(rhos)), space = 0,
        xlab = "Individuals", ylab = NULL,
        main="Original Baseline",yaxt="n",cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)
#abline(h=0.5, lty=2)

mtext(text="Prob. of origin",side=2,line=0,outer=TRUE,cex=1.5)

####################################

x = table(MixtureData$repunit); x = as.vector(x)
y = x/2
x = c(0,x[-length(x)]); x = cumsum(x)
y = y + x

MixtureData$repunit[MixtureData$repunit == "20"] = "POP1" #"Nes�y"
MixtureData$repunit[MixtureData$repunit == "22"] = "POP2" #"Myken"
MixtureData$repunit[MixtureData$repunit == "23"] = "POP3" #"Tr�na"
MixtureData$repunit[MixtureData$repunit == "24"] = "POP4" #"Selv�r"
MixtureData$repunit[MixtureData$repunit == "26"] = "POP5" #"Gjer�y"
MixtureData$repunit[MixtureData$repunit == "27"] = "POP6" #"Hestmann�y"
MixtureData$repunit[MixtureData$repunit == "28"] = "POP7" #"Indre Kvar�y"
MixtureData$repunit[MixtureData$repunit == "38"] = "POP8" #"Aldra"

text(y,-0.05, srt = 35, adj= 1.1, xpd = TRUE,labels = unique(MixtureData$repunit), cex=1.5)

####################################

# ADMIXTURE, Parametric bootstarp, support vector machine and network solution path methods:

par(oma=c(3,3,0,0),mar=c(3,3,2,2),mfrow=c(4,1))

barplot(MAssignPOPSVM, col = rainbow(length(rhos)), space = 0,
        xlab = NULL, ylab = NULL,
        main="AssignPOP (support vector machine)",yaxt="n", cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)

barplot(MNetworkSolPath, col = rainbow(length(rhos)), space = 0,
        xlab = NULL, ylab = "Prob. of origin",
        main="BONE (solution path)",yaxt="n", cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)

# Potential outgroup memebers:

ETs = NetworkResultsSolpath$OutgroupMembers
ETs = as.vector(ETs)

text(ETs,-0.07, adj=1,xpd = TRUE,labels = c("*"), cex=3) # Potential outgroup members marked with a star

######################

barplot(t(MADMIXTURE), col = rainbow(length(rhos)), space = 0,
        xlab = NULL, ylab = NULL,
        main="ADMIXTURE",yaxt="n", cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)

barplot(MTrue, col = rainbow(length(rhos)), space = 0,
        xlab = "Individuals", ylab = "Prob. of origin",
        main="Original Baseline",yaxt="n", cex.main=2)
axis(2, at=c(0,0.5,1),labels=c("0","0.5","1"), las=2, tck=-0.025, cex.axis=1.5)
#abline(h=0.5, lty=2)

mtext(text="Prob. of origin",side=2,line=0,outer=TRUE,cex=1.5)

text(y,-0.05, srt = 35, adj= 1.1, xpd = TRUE,labels = unique(MixtureData$repunit), cex=1.5)

####################################


year

# Save both figures as pdf, eps and tiff: landscape, a4 landscape. tiff & eps: 794 x 1123 pixels (a4 size)
# Name "ProbOriginBarplot". Smaller figure height 650 pixels and 6.5 inches.

######################

table(MixtureData$repunit)/sum(table(MixtureData$repunit)) # Empirical mixture proportions
rhos # Simulation model mixture proportions

par(mfrow=c(1,1))

ProbOriginGuess = rep(0,M) # Are results better than random guessing?
MixPropGuess = rep(0,M)

for(i in 1:M){
  Q = rdirichlet(ncol(MRUBIASMCMC), table(SmallBirdRef$repunit))
  Q = as.vector(t(Q))
  ProbOriginGuess[i] = MSE(Q,MixtureTruth$PofZ)
  MixPropGuess[i] = MSE(rhos,as.vector(gtools::rdirichlet(1, rhos)))
}

Results = cbind(Results,ProbOriginGuess,MixPropGuess)

boxplot(Results[,c(1,3,5,7,9,11,13)],main="Probability of origin MSE")
boxplot(Results[,c(2,4,6,8,10,12,14)],main="Mixing proportions MSE")

boxplot(Results[,c(1,3,5,7,9,11)],main="Probability of origin MSE")
boxplot(Results[,c(2,4,6,8,10,12)],main="Mixing proportions MSE")

###########################################################

write.table(Results,"SimulationResults.txt",quote=F)

write.table(MTrue,"MTrue.txt")

write.table(MRUBIASMCMC,"MRUBIASMCMC.txt")

write.table(t(MADMIXTURE),"MADMIXTURE.txt")

write.table(MAssignPOPNB,"MAssignPOPNB.txt")
write.table(MAssignPOPSVM,"MAssignPOPSVM.txt")

write.table(MNetworkWTA,"MNetworkWTA.txt")
write.table(MNetworkSolPath,"MNetworkSolPath.txt")

###########################################################

# Plot the solution path of one potential outgroup member and some other mixture individual
# to demonstrate the difference between LASSO solution paths:

ETs = NetworkResultsSolpath$OutgroupMembers
ET = sample(ETs,1)

NoET = NetworkResultsSolpath$ProbofOrigin
NoET = order(NoET[,9],decreasing = T)[1:9]
NoET = sample(NoET,1)
MixtureSmaller[NoET,]
names(NoET) = MixtureSmaller$indiv[NoET]

length(lambda)

Classes = IndivProbsMCMC$repunit[1:length(rhos)]

Classes[Classes=="20"] = "POP1"
Classes[Classes=="22"] = "POP2"
Classes[Classes=="23"] = "POP3"
Classes[Classes=="24"] = "POP4"
Classes[Classes=="26"] = "POP5"
Classes[Classes=="27"] = "POP6"
Classes[Classes=="28"] = "POP7"
Classes[Classes=="38"] = "POP8"

b = length(Classes)
NmbOfNeighbors = NetworkResultsSolpath$NmbOfNeighbors

# rows are in order: 

sort(unique(ReferenceData$repunit))

rownames(NmbOfNeighbors) = sort(unique(ReferenceData$repunit))

# Reorder rows, just that colors are in logical order compared to the barplots plotted before:

NmbOfNeighbors = NmbOfNeighbors[IndivProbsMCMC$repunit[1:length(rhos)],,]

#############################

LineColors = rainbow(b)

pdf("SolutionPathOutsiderInsider.pdf", paper="a4r")
par(mfrow=c(2,1))

for(i in 1:nrow(NmbOfNeighbors)){

  if(i == 1) plot(1:length(lambda), NmbOfNeighbors[i,ET, ], col=LineColors[i], ylim=c(0,max(NmbOfNeighbors[,ET,])), 
                  xlab="lambda", ylab="Nmb of neighbors", type="l", cex.axis=0.8, lwd=1.5,
                  main=paste("Potential outsider, weak genetic connection (id",names(ET),")",sep=" "), las=1)
  
  if(i > 1) lines(1:length(lambda), NmbOfNeighbors[i,ET, ], col=LineColors[i], lwd=1.5)

}

for(i in 1:nrow(NmbOfNeighbors)){
  
  if(i == 1) plot(1:length(lambda), NmbOfNeighbors[i,NoET, ], col=LineColors[i], ylim=c(0,max(NmbOfNeighbors[,NoET,])), 
                  xlab="lambda", ylab="Nmb of neighbors", type="l", cex.axis=0.8, lwd=1.5,
                  main=paste("Random individual, strong genetic connection (id",names(NoET),")",sep=" "), las=1)
  
  if(i > 1) lines(1:length(lambda), NmbOfNeighbors[i,NoET, ], col=LineColors[i], lwd=1.5)
  
}

dev.off()

##########

pdf("SolutionPathOutsider.pdf", paper="a4r")
par(mfrow=c(2,2),oma = c(0, 0, 2, 0))

for(i in 1:length(lambda)){

  barplot(NmbOfNeighbors[,ET,i],col=rainbow(b),names.arg=Classes,
          ylim=c(0,max(NmbOfNeighbors[,ET,])),main=paste("lambda",i),cex.names = 0.5)

  if(i %% 4 == 0) mtext(paste("Potential outsider, weak genetic connection (id",names(ET),")",sep=" "), outer = T, cex = 1.5)

}

dev.off()

pdf("SolutionPathInGroup.pdf", paper="a4r")
par(mfrow=c(2,2),oma = c(0, 0, 2, 0))

for(i in 1:length(lambda)){
  
  barplot(NmbOfNeighbors[,NoET,i],col=rainbow(b),names.arg=Classes,
          ylim=c(0,max(NmbOfNeighbors[,NoET,])),main=paste("lambda",i),cex.names = 0.5)
  
  if(i %% 4 == 0) mtext(paste("Random individual, strong genetic connection (id",names(NoET),")",sep=" "), outer = T, cex = 1.2)
  
}

dev.off()

save.image()
#Workspace is in file ".RData"
#load(".RData")


# How many SNPs were removed and imputed in average?

apply(ModifiedSNPs,2,mean)/2000 # Include SNPs twice: both mixture and baseline data
