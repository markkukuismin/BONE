
radmixtureEstimator = function(MixtureData, ReferenceData, SmallBirdRefADMIXTURE){
  
  IndivProbsADMIXTURE = matrix(0,nrow = nrow(MixtureData), ncol = length(unique(ReferenceData$repunit)))
  
  colnames(IndivProbsADMIXTURE) = unique(ReferenceData$repunit)
  
  for(i in 1:nrow(MixtureData)){
    
    ADMIXData = SmallBirdRefADMIXTURE
    
    ADMIXTUREPop = ReferenceData[ ,c(2,4)]
    
    AD = MixtureData[i ,c(2,4)]
    
    AD[ ,1] = "-"
    
    ADMIXTUREPop = rbind(ADMIXTUREPop,AD)
    
    colnames(ADMIXTUREPop) = c("pop","ID")
    
    rownames(ADMIXTUREPop) = ADMIXTUREPop$ID
    
    rownames(ADMIXData) = ADMIXData$V2
    
    ADMIXData = ADMIXData[ADMIXTUREPop$ID, ]
    
    ADMIXData$V1 = as.character(ADMIXData$V1)
    ADMIXData$V2 = as.character(ADMIXData$V2)
    ADMIXData$V3 = as.character(ADMIXData$V3)
    ADMIXData$V4 = as.character(ADMIXData$V4)
    
    G = generateG(ADMIXData)
    
    initQ = initQF(g = G, pop = ADMIXTUREPop, model="supervised")
    
    ADMIXTURERes = em(g=G, q=initQ$q, f=initQ$f, acc=F, tol=1e-4, model="supervised")
    
    IndivProbsADMIXTURE[i, ] = last(ADMIXTURERes$q, 1)
    
    cat("\r", i)
    
  }
  
  return(IndivProbsADMIXTURE)
  
}