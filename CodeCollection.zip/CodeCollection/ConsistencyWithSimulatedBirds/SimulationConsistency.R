
# 03.09.2019

library(glmnet)
library(rubias)
library(gtools)
library(igraph)
library(data.table)
library(radmixture)

##########################################################################

# Use SNP data from house sparrow. The data set should be available at DataDryad:

Classes = rep("character",366296) # The number of columns in the data file

year = 2012

# This is the file path of the .ped file. Change it!

BirdFile = paste("C:/Users/Desktop/HighSparrow/AllYears/All_years_1998-2012/",year,"/Baseline/",
                 "Basepop",year,"_200K.ped",sep="")

BirdRef = fread(BirdFile, colClasses = Classes)

BirdRefADMIXTURE = BirdRef

BirdRef = BirdRef[,-c(1,3,4,5,6)]

str(BirdRef[,1:3])

# This is the file path of the ref file. Change it!

repunitfile = paste("C:/Users/Desktop/HighSparrow/AllYears/All_years_1998-2012/",year,"/Baseline/",
                    "alladults",year,"_basepop_ref.txt",sep="")

repunit = read.table(repunitfile,header=F,colClasses = c("character","character"))

str(repunit)

dim(BirdRef)

# Comming up next, a lot of tiresome data modifications...

all.equal(BirdRef$V2,repunit$V1) # Not in the same order...

BirdRef = BirdRef[match(repunit$V1,BirdRef$V2),]
BirdRefADMIXTURE = BirdRefADMIXTURE[match(repunit$V1,BirdRefADMIXTURE$V2),]

all.equal(BirdRefADMIXTURE$V2,repunit$V1) # Now samples are in order

SampleSizeBaseline = nrow(BirdRef)

# Modify dataset for rubias:

BirdRef = BirdRef[,-1] # Makes the conversion to numeric variables easier (1)
BirdRef = as.matrix(BirdRef) # This makes replacing values much faster

BirdRefADMIXTURE = as.matrix(BirdRefADMIXTURE)

# Here I follow the coding of Anderson: https://github.com/eriqande/gsi_sim

BirdRef[BirdRef == "0"] <- NA # Missing values
BirdRef[BirdRef == "A"] <- 1
BirdRef[BirdRef == "C"] <- 2
BirdRef[BirdRef == "G"] <- 3
BirdRef[BirdRef == "T"] <- 4

BirdRefADMIXTURE[BirdRefADMIXTURE == "0"] <- 0 # Missing values
BirdRefADMIXTURE[BirdRefADMIXTURE == "A"] <- 1
BirdRefADMIXTURE[BirdRefADMIXTURE == "C"] <- 2
BirdRefADMIXTURE[BirdRefADMIXTURE == "G"] <- 3
BirdRefADMIXTURE[BirdRefADMIXTURE == "T"] <- 4

BirdRef = as.data.frame(BirdRef,stringsAsFactors=F)

BirdRefADMIXTURE = as.data.frame(BirdRefADMIXTURE,stringsAsFactors=F)

str(BirdRef[ ,1:10])

str(BirdRefADMIXTURE[ ,1:11])

BirdRef = cbind(repunit, BirdRef)

BirdRef[1:3, 1:5]

colnames(BirdRef)[1:2] = c("indiv", "repunit")

str(BirdRef[ ,1:10])

BirdRefADMIXTURE[1:5,1:7]

table(BirdRef$repunit)

# Choose three of the largest populations and one dummy individual:

Ind = BirdRef$repunit %in% c("24", "26", "27")

Ind[length(Ind)] = T # The dummy

BirdRef = BirdRef[Ind, ]

table(BirdRef$repunit)

BirdRefADMIXTURE = BirdRefADMIXTURE[BirdRefADMIXTURE[,2] %in% BirdRef$indiv, ]

# Simulate data with ADMIXTURE model:

dim(BirdRefADMIXTURE)

str(BirdRefADMIXTURE[ ,1:10])

Data = BirdRefADMIXTURE[ ,7:ncol(BirdRefADMIXTURE)]

Data = mapply(Data, FUN=as.integer)

BirdRefADMIXTURE = cbind(BirdRefADMIXTURE[ ,1:4], as.numeric(BirdRefADMIXTURE$V5), as.numeric(BirdRefADMIXTURE$V6), Data)

colnames(BirdRefADMIXTURE)[c(5,6)] = c("V5", "V6")

#########################################################################
  
G = generateG(BirdRefADMIXTURE) # ncol(G) = nmb of non-missing genotypes of ADMIXData

dim(G)

Pops = BirdRef[ ,c(2,1)]

colnames(Pops) = c("pop","ID")

rownames(Pops) = Pops$ID

table(Pops$pop)

initQ = initQF(g = G, pop = Pops, model="supervised")

# Only the F matrix is needed:

Fmatrix = initQ$f

dim(Fmatrix)

##########################################################################

# Fix the Q matrix:

HugePopsSize = 1500

Q = matrix(0,HugePopsSize,nrow(Fmatrix))

Q[1:500, 1] = 1
Q[501:1000, 2] = 1
Q[1001:1500, 3] = 1

##########################################################################

# Now we can simulate the SNP data

G1 = Q%*%Fmatrix
dim(G1)
G1[1:5,1:5]

G2 = Q%*%(1-Fmatrix)

IsOne = G1^2 + 2*G1*G2 + G2^2

all.equal(IsOne, matrix(1,nrow(IsOne), ncol(IsOne)))

N = nrow(Q)
L = ncol(Fmatrix)

SimSnps = matrix(NA,N,L)

for(i in 1:N){
  for(j in 1:L){
    
    SimSnps[i,j] = sample(c(2,1,0),1,prob=c(G1[i,j]^2,2*G1[i,j]*G2[i,j],G2[i,j]^2))
    
  }
}

dim(SimSnps) # nrow = nmb of individuals, ncol = nmb of SNPs

##########################################################################

# Use just small proportion of SNPs:

SNPNumber = c(500, 1000, 5000, 20000)

# Load functions needed for the network inference method:

source("../SimulationBirds/NetworkMethod/impute.R")
source("../SimulationBirds/NetworkMethod/LASSOSolPath.R")
source("../SimulationBirds/NetworkMethod/SolPathInference.R")
source("../SimulationBirds/NetworkMethod/WTAInference.R")

MSE = function(x,y){
  
  mean((x-y)^2)
  
}

# Draw 100 baseline individuals from three large population and 10, 20 and 50 mixture individuals
# from these population: 

b = c(100, 100, 100)
m = c(10, 20, 50)

M = 50 # Number of simulation rounds

ResultsWTA = data.table(V1=rep(0,M), V2=rep(0,M), V3=rep(0,M), V4=rep(0,M), V6=rep("WTA",M))
colnames(ResultsWTA) = c(SNPNumber,"Method")

ResultsSolPath = data.table(V1=rep(0,M), V2=rep(0,M), V3=rep(0,M), V4=rep(0,M), V6=rep("SolPath",M))
colnames(ResultsSolPath) = c(SNPNumber,"Method")

MixingPropWTA = ResultsWTA
MixingPropSolPath = ResultsSolPath

ProbOriginWTA = ResultsWTA
ProbOriginSolPath = ResultsSolPath

for(q in 1:length(SNPNumber)){
  
  n = SNPNumber[q]
  
  # Systematic sampling:
  
  k = ncol(SimSnps)/n # Skip
  r = runif(1,0,k) # Start value
  ind = seq(r, r + k*(n-1), k)
  ind = ceiling(ind)
  
  ############################################################
  ############################################################
  
  for(z in 1:M){
    
    SA = sample(1:500, b[1] + m[1])
    SA = sort(SA)
    
    SB = sample(501:1000, b[2] + m[2])
    SB = sort(SB)
    
    SC = sample(1001:1500, b[3] + m[3])
    SC = sort(SC)
    
    Reference = c(SA[1:b[1]], SB[1:b[2]], SC[1:b[3]])
    
    Mixture = c(SA[101:(b[1] + m[1])], SB[101:(b[2] + m[2])], SC[101:(b[3] + m[3])])
    Mixture = sort(Mixture)
    
    ReferenceData = SimSnps[Reference, ind]
    ReferenceData = as.data.frame(ReferenceData)
    
    MixtureData = SimSnps[Mixture, ind]
    MixtureData = as.data.frame(MixtureData)
    
    ################################################
    
    SampleSizeBaselinePop = nrow(ReferenceData)
    
    Y = cbind(t(ReferenceData),t(MixtureData))
    
    colnames(Y) = as.character(1:ncol(Y))
    
    sample_type = rep("reference", nrow(ReferenceData))
    
    repunit = c(rep("POP1", b[1]), rep("POP2", b[2]), rep("POP3", b[3]))
    
    collection = c(rep("POP1.1", b[1]), rep("POP2.1", b[2]), rep("POP3.1", b[3]))
    
    indiv = as.character(1:nrow(ReferenceData)) # Fake ID
    
    ReferenceData = cbind(sample_type, repunit, collection, indiv, ReferenceData, stringsAsFactors = FALSE)
    
    ##
    
    sample_type = rep("mixture", nrow(MixtureData))
    
    repunit = rep(NA_character_, sum(m))
    
    collection = rep("rec1", sum(m))
    
    indiv = as.character((nrow(ReferenceData) + 1):ncol(Y)) # Fake ID
    
    MixtureData = cbind(sample_type, repunit, collection, indiv, MixtureData, stringsAsFactors = FALSE)
    
    ###########################################################################
    
    MixtureTruth = data.frame(repunit = c(rep("POP1", m[1]), rep("POP2", m[2]), rep("POP3", m[3])),
                              indiv=MixtureData$indiv,stringsAsFactors = F)
    
    ###########################################################################
    
    ################
    # Network method
    ################
    
    lambda = seq(0.4,0.02,length.out=40)
    
    NeighborhoodSolPath = LASSOSolPath(Y,lambda=lambda,SampleSizeBaselinePop=SampleSizeBaselinePop) 
    
    # NB: Non-symmetric network!
    
    #################################
    
    # Winner takes it all approach:
    
    NetworkResultsWTA = WTAInference(MBapprox=NeighborhoodSolPath,ReferenceData=ReferenceData,SampleNames=colnames(Y),
                                      SampleSizeBaselinePop=SampleSizeBaselinePop,NmbOfParents=1) #(*)
    
    NetworkIndivPofzWTA = NetworkResultsWTA$ProbofOrigi
    
    ################################
    
    # Solution path approach:
    
    NetworkResultsSolpath = SolPathInference(MBapprox=NeighborhoodSolPath,ReferenceData=ReferenceData,
                                             SampleNames=colnames(Y),SampleSizeBaselinePop=SampleSizeBaselinePop)
    
    NetworkIndivPofzSolPath = NetworkResultsSolpath$ProbofOrigi
    
    ##########################################################################
    ##########################################################################
    
    Islands = colnames(NetworkIndivPofzWTA) # Names of islands (numeric code) as they appear in pop.orgin tables
    
    AssignmentsWTA = apply(NetworkIndivPofzWTA,1,which.max)
    AssignmentsSolPath = apply(NetworkIndivPofzSolPath[,-ncol(NetworkIndivPofzSolPath)],1,which.max)
    
    ResultsWTA[z,q] = mean(Islands[AssignmentsWTA] == MixtureTruth$repunit) # Percentage of correct assignments
    ResultsSolPath[z,q] = mean(Islands[AssignmentsSolPath] == MixtureTruth$repunit) # Percentage of correct assignments
    
    ProbOriginWTA[z,q] = MSE(NetworkResultsWTA$ProbofOrigin, Q[Mixture, ])
    
    ProbOriginSolPath[z,q] = MSE(NetworkResultsSolpath$ProbofOrigin[, -4], Q[Mixture, ])
    
    MixingPropWTA[z,q] = MSE(NetworkResultsWTA$MixtureProp, m/sum(m))
    
    MixingPropSolPath[z,q] = MSE(NetworkResultsSolpath$MixtureProp, m/sum(m))
    
  }
  
  cat("\r",q)
  
}

m/sum(m) # Simulation model mixture proportions

par(mfrow=c(1,2))

boxplot(ProbOriginWTA[,-5],main="Prob. of Origin MSE WTA")
boxplot(ProbOriginSolPath[,-5],main="Prob. of Origin MSE Sol. Path")

boxplot(MixingPropWTA[,-5],main="Mixing Prop. MSE WTA")
boxplot(MixingPropSolPath[,-5],main="Mixing Prop. MSE Sol. Path")

boxplot(ResultsWTA[,-5],main="Assignment accuracy WTA")
boxplot(ResultsSolPath[,-5],main="Assignment accuracy Sol. Path")

###########################################################

save.image("Consistency.RData")

AssignmentResults = rbind(ResultsWTA,ResultsSolPath)

ProbOriginResults = rbind(ProbOriginWTA, ProbOriginSolPath)

MixingPropResults = rbind(MixingPropWTA,MixingPropSolPath)

write.table(AssignmentResults,"AssignmentConsistencyResults.txt",quote=F)
write.table(ProbOriginResults,"ProbOriginMSEConsistencyResults.txt",quote=F)
write.table(MixingPropResults,"MixingPropMSEConsistencyResults.txt",quote=F)
