
# 12.08.2019

library(ggplot2)
library(reshape)
library(grid)
library(gridExtra)
library(scales)
library(gtable)

ResultsAssignment = read.table("AssignmentConsistencyResults.txt",header=T,check.names = F,stringsAsFactors = F)

ResultsAssignment$Method[ResultsAssignment$Method == "SolPath"] = "Solution path"

ResultsAssignment = melt(ResultsAssignment)

colnames(ResultsAssignment) = c("Method","NumberofSNPsused", "Assignmentaccuracy")

BoxplotAssignments = ggplot(ResultsAssignment, aes(NumberofSNPsused, Assignmentaccuracy)) + 
  geom_boxplot() +
  theme(axis.text=element_text(size=9),axis.title=element_text(size=12,face="bold"),
        strip.text.x = element_text(size=12, face="bold")) 

BoxplotAssignments + facet_grid(cols = vars(Method)) + labs(y="Assignment accuracy\n",x=NULL)

p1 = BoxplotAssignments + facet_grid(cols = vars(Method)) + labs(y="Assignment accuracy\n",x=NULL)

##########################################################################

scientific_10=function(x){
  ifelse(x==0, "0", parse(text=gsub("[+]", "", gsub("e", " %*% 10^", scientific_format()(x)))))
}

##########################################################################

ResultsMixprop = read.table("MixingPropMSEConsistencyResults.txt",header=T,check.names = F,stringsAsFactors = F)

ResultsMixprop$Method[ResultsMixprop$Method == "SolPath"] = "Solution path"

ResultsMixprop = melt(ResultsMixprop)

colnames(ResultsMixprop) = c("Method","NumberofSNPsused", "MSE")

#BoxplotMixtureprop = ggplot(ResultsMixprop, aes(NumberofSNPsused, MSE)) + 
#  geom_boxplot() + 
#  theme(axis.text=element_text(size=8),axis.title=element_text(size=12,face="bold"),
#        strip.text.x = element_text(size=12, face="bold")) + 
#  scale_y_continuous(label=scientific_10)

BoxplotMixtureprop = ggplot(ResultsMixprop, aes(NumberofSNPsused, MSE)) + 
  geom_boxplot() + 
  theme(axis.text=element_text(size=8),axis.title=element_text(size=12,face="bold"),
        strip.text.x = element_text(size=12, face="bold"))

BoxplotMixtureprop + facet_grid(cols = vars(Method)) + labs(y="Mixture prop. MSE\n",x="Number of SNPs used")

p2 = BoxplotMixtureprop + facet_grid(cols = vars(Method)) + labs(y="Mixture prop. MSE\n",x="Number of SNPs used")

#############################

grid.arrange(p1, p2, nrow=2)

#############################

# Still want to align plots nicely:

p1 = ggplotGrob(p1)
p2 = ggplotGrob(p2)
g = rbind(p1, p2, size = "first")
g$widths = unit.pmax(p1$widths, p2$widths)
grid.newpage()
grid.draw(g)

#############################

scale = 0.8
pdf("SimulationConsistencyResults.pdf", width = 10*scale, height = 7*scale)
grid.draw(g)
dev.off()

#############################

##########################################################################

ResultsProbOrigin = read.table("ProbOriginMSEConsistencyResults.txt",header=T,check.names = F,stringsAsFactors = F)

ResultsProbOrigin$Method[ResultsProbOrigin$Method == "SolPath"] = "Solution path"

ResultsProbOrigin = melt(ResultsProbOrigin)

colnames(ResultsProbOrigin) = c("Method","NumberofSNPsused", "MSE")


BoxplotProbOrigin = ggplot(ResultsProbOrigin, aes(NumberofSNPsused, MSE)) + 
  geom_boxplot() + 
  theme(axis.text=element_text(size=8),axis.title=element_text(size=12,face="bold"),
        strip.text.x = element_text(size=12, face="bold"))

BoxplotMixtureprop + facet_grid(cols = vars(Method)) + labs(y="Prob. origin MSE\n",x="Number of SNPs used")