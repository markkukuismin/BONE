
# 11.6.2019 

# First rows are just to check how "generateG" handles missing genotypes

ExpendableDummy = rep(0,ncol(ADMIXData[,-(1:6)]))

Adnames = colnames(ADMIXData)

Adnames = Adnames[-c(1:6)]

k = 1

for(i in Adnames){
  
  ExpendableDummy[k] = sum(ADMIXData[,i] == 0)
  
  k = k + 1
  
}

sum(ExpendableDummy != 0)

(ncol(ADMIXData[ ,-c(1:6)]) - sum(ExpendableDummy != 0))/2

###################################################

Fmatrix = initQ$f

Q = matrix(0,35,nrow(Fmatrix))

table(ADMIXTUREPop$pop)

Q[1:5, 1] = 1
Q[6:10, 2] = 1
Q[11:15, 3] = 1
Q[16:20, 4] = 1
Q[21:25, 5] = 1
Q[26:30, 6] = 1
Q[31:35, 7] = 1

barplot(t(Q), col=rainbow(ncol(Q)))

G1 = Q%*%Fmatrix
dim(G1)
G1[1:5,1:5]

G2 = Q%*%(1-Fmatrix)

IsOne = G1^2 + 2*G1*G2 + G2^2

all.equal(IsOne, matrix(1,nrow(IsOne), ncol(IsOne)))

N = nrow(Q)
L = ncol(Fmatrix)

SimSnps = matrix(NA,N,L)

for(i in 1:N){
  for(j in 1:L){
    
    SimSnps[i,j] = sample(c(0,1,2),1,prob=c(G1[i,j]^2,2*G1[i,j]*G2[i,j],G2[i,j]^2))
    
  }
}

##################################################

# ADMIXTURE analysis

str(SimSnps[,1:10])
str(G[,1:10])

FlatPrior = rdirichlet(nrow(SimSnps), rep(1, ncol(Q))) # So called flat prior for alpha in "initQF"

barplot(t(FlatPrior), col=rainbow(ncol(Q))) # (*)

qf = initQF(SimSnps, K=7, alpha = 1, model = "unsupervised")

barplot(t(qf$q), col=rainbow(ncol(Q))) # (*) same as above  (random of cource)

res = qn(SimSnps, qf$q, qf$f, tol = 1e-4, "EM", "unsupervised") # This is really, really slow...

dim(res$q)

par(mfrow=c(2,1))

barplot(t(Q), col=rainbow(ncol(Q)), main="Truth")

barplot(t(res$q), col=rainbow(ncol(Q)), main="ADMIXTURE")

# So the label switching problem is evident, let's help ADMIXTURE out:

Qest = res$q

for(i in 1:nrow(ExpendableDummy)){
  
  Qest[i, ] = sort(Qest[i,])
  
}

Qest[1:5, ] = Qest[1:5,c(7,6,5,4,3,2,1)]
Qest[6:10, ] = Qest[6:10,c(6,7,5,4,3,2,1)]
Qest[11:15, ] = Qest[11:15,c(5,6,7,4,3,2,1)]
Qest[16:20, ] = Qest[16:20,c(4,6,5,7,3,2,1)]
Qest[21:25, ] = Qest[21:25,c(3,6,5,4,7,2,1)]
Qest[26:30, ] = Qest[26:30,c(2,6,5,4,3,7,1)]
Qest[31:35, ] = Qest[31:35,c(1,6,5,4,3,2,7)]


par(mfrow=c(2,1))

barplot(t(Q), col=rainbow(ncol(Q)), main="Truth")

barplot(t(Qest), col=rainbow(ncol(Qest)), main="ADMIXTURE, ordered")
