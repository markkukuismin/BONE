
# 03.09.2019

library(ggplot2)
library(reshape)
library(gridExtra)

Results = read.table("SimulationResultsMSE.txt",header=T)

ResultsProbOrigin = Results[,c(1,3,6,8,10,12)]
colnames(ResultsProbOrigin) = c("ADMIXTURE","Rubias","BONE WTA", "BONE SP",
                                "AssignPOP SVM","AssignPOP nB")

ResultsMixProp = Results[,c(2,4,5,7,9,11,13)]
ResultsMixProp = ResultsMixProp[ ,-3] # Looks bad...
colnames(ResultsMixProp) = c("ADMIXTURE","Rubias","BONE WTA", "BONE SP",
                             "AssignPOP SVM","AssignPOP nB")

# The mixture proportions for the guessing are way too big for nice boxplots...

MeltData = melt(ResultsProbOrigin)
colnames(MeltData) = c("Method","MSE")

BoxplotProbOrigin = ggplot(MeltData) +
  geom_boxplot(aes(x=Method, y=MSE)) +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=12,face="bold")) + 
  ggtitle("Probability of the origin estimates") +
  labs(y="MSE\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

plot(BoxplotProbOrigin)

median(Results$ProbOriginGuess)
sd(Results$ProbOriginGuess)

MeltData = melt(ResultsMixProp)
colnames(MeltData) = c("Method","MSE")

BoxplotMixProp = ggplot(MeltData) +
  geom_boxplot(aes(x=Method, y=MSE)) +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=12,face="bold")) + 
  ggtitle("Mixture proportion estimates") +
  labs(y=NULL) +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

plot(BoxplotMixProp)

median(Results$MixPropGuess)
sd(Results$MixPropGuess)

grid.arrange(BoxplotProbOrigin,BoxplotMixProp,ncol=2)

#############################

scale = 0.8
pdf("ProbabOriginAndMixtureProp.pdf", width = 15*scale, height = 5*scale)
grid.arrange(BoxplotProbOrigin,BoxplotMixProp,ncol=2)
dev.off()
