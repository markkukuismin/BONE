
radmixtureEstimator = function(MixtureData, ReferenceData, G){
  
  IndivProbsADMIXTURE = matrix(0,nrow = nrow(MixtureData), ncol = length(unique(ReferenceData$repunit)))
  
  colnames(IndivProbsADMIXTURE) = unique(ReferenceData$repunit)
  
  for(i in 1:nrow(MixtureData)){
    
    ADMIXTUREPop = ReferenceData[ ,c(2,4)]
    
    AD = MixtureData[i ,c(2,4)]
    
    AD[ ,1] = "-"
    
    ADMIXTUREPop = rbind(ADMIXTUREPop,AD)
    
    colnames(ADMIXTUREPop) = c("pop","ID")
    
    rownames(ADMIXTUREPop) = ADMIXTUREPop$ID
    
    GG = G[ADMIXTUREPop$ID, ]
    
    initQ = initQF(g = GG, pop = ADMIXTUREPop, model="supervised")
    
    ADMIXTURERes = qn(g=GG, q=initQ$q, f=initQ$f, tol=1e-4, model="supervised", method="BR")
    
    IndivProbsADMIXTURE[i, ] = ADMIXTURERes$q
    
    cat("\r", i)
    
  }
  
  return(IndivProbsADMIXTURE)
  
}