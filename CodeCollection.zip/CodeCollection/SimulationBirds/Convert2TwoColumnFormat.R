
Convert2TwoColumnformat = function(A){
  
  B = matrix(0,nrow(A))
  
  Samplematrix = cbind(c(1,4,1,1,4,4,3,3,2,2,2,3), c(4,1,3,2,3,2,4,1,4,1,3,2))
  
  for(i in 1:ncol(A)){
    
    D0 = sweep(cbind(A[ ,i] == 0, A[ ,i] == 0), 2, Samplematrix[sample(1:2,1), ], FUN="*")
    
    D1 = sweep(cbind(A[ ,i] == 1, A[ ,i] == 1), 2, Samplematrix[sample(3:10,1), ], FUN="*")
    
    D2 = sweep(cbind(A[ ,i] == 2, A[ ,i] == 2), 2, Samplematrix[sample(11:12,1), ], FUN="*")
    
    D = D0 + D1 + D2
    
    B = cbind(B,D)
    
  }
  
  B = B[,-1]
  
  return(B)
  
}